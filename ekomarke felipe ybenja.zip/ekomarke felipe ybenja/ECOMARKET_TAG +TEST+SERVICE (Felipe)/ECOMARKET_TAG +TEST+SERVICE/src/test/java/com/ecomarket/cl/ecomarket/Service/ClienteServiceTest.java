package com.ecomarket.cl.ecomarket.Service;

import com.ecomarket.cl.ecomarket.model.CarritoCompra;
import com.ecomarket.cl.ecomarket.model.Cliente;
import com.ecomarket.cl.ecomarket.repository.ClienteRepository;
import com.ecomarket.cl.ecomarket.service.ClienteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;


public class ClienteServiceTest {

    private Cliente cliente;

    @BeforeEach
    void setUp() {
        cliente = new Cliente();
        cliente.setRut("55555555-5");
        cliente.setNombre("Andrea Muñoz");
        cliente.setCorreo("andrea.munoz@email.com");
        cliente.setDireccion("Calle Primavera 100");
        cliente.setTelefono("123456789");
        cliente.setDireccionEnvio("Calle Primavera 100");
    }

    @Test
    void testConstructorConParametros() {
        Cliente nuevoCliente = new Cliente(
                "66666666-6",
                "Felipe Salinas",
                "felipe.salinas@email.com",
                "Avenida Mar 200",
                "987654321",
                "Avenida Mar 200",
                true
        );
        assertEquals("66666666-6", nuevoCliente.getRut());
        assertEquals("Felipe Salinas", nuevoCliente.getNombre());
        assertEquals("felipe.salinas@email.com", nuevoCliente.getCorreo());
        assertEquals("Avenida Mar 200", nuevoCliente.getDireccion());
        assertEquals("987654321", nuevoCliente.getTelefono());
        assertEquals("Avenida Mar 200", nuevoCliente.getDireccionEnvio());
        assertNotNull(nuevoCliente.getCarrito());
    }

    @Test
    void testGettersAndSetters() {
        assertEquals("55555555-5", cliente.getRut());
        assertEquals("Andrea Muñoz", cliente.getNombre());
        assertEquals("andrea.munoz@email.com", cliente.getCorreo());
        assertEquals("Calle Primavera 100", cliente.getDireccion());
        assertEquals("123456789", cliente.getTelefono());
        assertEquals("Calle Primavera 100", cliente.getDireccionEnvio());

        cliente.setDireccionEnvio("Nueva Direccion 123");
        assertEquals("Nueva Direccion 123", cliente.getDireccionEnvio());

        CarritoCompra nuevoCarrito = new CarritoCompra(cliente);
        cliente.setCarrito(nuevoCarrito);
        assertEquals(nuevoCarrito, cliente.getCarrito());
    }

    @Test
    void testRealizarPedido() {
        // Solo verifica que el método se ejecuta sin lanzar excepción
        assertDoesNotThrow(() -> cliente.realizarPedido());
    }
}