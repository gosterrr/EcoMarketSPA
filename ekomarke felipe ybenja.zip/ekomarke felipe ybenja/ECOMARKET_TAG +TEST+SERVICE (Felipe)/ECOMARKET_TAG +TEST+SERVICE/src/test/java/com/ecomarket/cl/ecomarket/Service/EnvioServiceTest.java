package com.ecomarket.cl.ecomarket.Service;

import com.ecomarket.cl.ecomarket.model.Envio;
import com.ecomarket.cl.ecomarket.repository.EnvioRepository;
import com.ecomarket.cl.ecomarket.service.EnvioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class EnvioServiceTest {

    @Mock
    private EnvioRepository envioRepository;

    @InjectMocks
    private EnvioService envioService;

    private Envio envio;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        envio = new Envio();
        envio.setId(1L);
        envio.setDireccionDestino("Av. Los Pinos 123");
        envio.setCiudad("Santiago");
        envio.setRegion("Metropolitana");
        envio.setCodigoPostal("8320000");
        envio.setEstado("En tránsito");
        envio.setMetodoEnvio("Express");
        envio.setFechaEnvio(LocalDate.of(2025, 6, 19));
        envio.setFechaEntregaEstimada(LocalDate.of(2025, 6, 21));
    }

    @Test
    void testObtenerTodos() {
        when(envioRepository.findAll()).thenReturn(List.of(envio));
        List<Envio> envios = envioService.obtenerTodos();
        assertEquals(1, envios.size());
        Envio e = envios.get(0);
        assertEquals("Av. Los Pinos 123", e.getDireccionDestino());
        assertEquals("Santiago", e.getCiudad());
        assertEquals("Metropolitana", e.getRegion());
        assertEquals("8320000", e.getCodigoPostal());
        assertEquals("En tránsito", e.getEstado());
        assertEquals("Express", e.getMetodoEnvio());
        assertEquals(LocalDate.of(2025, 6, 19), e.getFechaEnvio());
        assertEquals(LocalDate.of(2025, 6, 21), e.getFechaEntregaEstimada());
        assertEquals(1L, e.getId());
    }

    @Test
    void testObtenerPorId() {
        when(envioRepository.findById(1L)).thenReturn(Optional.of(envio));
        Optional<Envio> result = envioService.obtenerPorId(1L);
        assertTrue(result.isPresent());
        Envio e = result.get();
        assertEquals("Av. Los Pinos 123", e.getDireccionDestino());
        assertEquals("Santiago", e.getCiudad());
        assertEquals("Metropolitana", e.getRegion());
        assertEquals("8320000", e.getCodigoPostal());
        assertEquals("En tránsito", e.getEstado());
        assertEquals("Express", e.getMetodoEnvio());
        assertEquals(LocalDate.of(2025, 6, 19), e.getFechaEnvio());
        assertEquals(LocalDate.of(2025, 6, 21), e.getFechaEntregaEstimada());
        assertEquals(1L, e.getId());
    }

    @Test
    void testGuardar() {
        when(envioRepository.save(envio)).thenReturn(envio);
        Envio guardado = envioService.guardar(envio);
        assertNotNull(guardado);
        assertEquals("Av. Los Pinos 123", guardado.getDireccionDestino());
        assertEquals("Santiago", guardado.getCiudad());
        assertEquals("Metropolitana", guardado.getRegion());
        assertEquals("8320000", guardado.getCodigoPostal());
        assertEquals("En tránsito", guardado.getEstado());
        assertEquals("Express", guardado.getMetodoEnvio());
        assertEquals(LocalDate.of(2025, 6, 19), guardado.getFechaEnvio());
        assertEquals(LocalDate.of(2025, 6, 21), guardado.getFechaEntregaEstimada());
        assertEquals(1L, guardado.getId());
    }

    @Test
    void testEliminar() {
        doNothing().when(envioRepository).deleteById(1L);
        envioService.eliminar(1L);
        verify(envioRepository, times(1)).deleteById(1L);
    }

    @Test
    void testObtenerPorIdNoExistente() {
        when(envioRepository.findById(2L)).thenReturn(Optional.empty());
        Optional<Envio> result = envioService.obtenerPorId(2L);
        assertFalse(result.isPresent());
    }

    @Test
    void testObtenerTodosVacio() {
        when(envioRepository.findAll()).thenReturn(List.of());
        List<Envio> envios = envioService.obtenerTodos();
        assertTrue(envios.isEmpty());
    }

    @Test
    void testGuardarEnvioConTodosLosAtributos() {
        Envio nuevoEnvio = new Envio();
        nuevoEnvio.setId(3L);
        nuevoEnvio.setDireccionDestino("Calle Nueva 456");
        nuevoEnvio.setCiudad("Valparaíso");
        nuevoEnvio.setRegion("Valparaíso");
        nuevoEnvio.setCodigoPostal("2340000");
        nuevoEnvio.setEstado("Pendiente");
        nuevoEnvio.setMetodoEnvio("Normal");
        nuevoEnvio.setFechaEnvio(LocalDate.of(2025, 7, 1));
        nuevoEnvio.setFechaEntregaEstimada(LocalDate.of(2025, 7, 3));

        when(envioRepository.save(nuevoEnvio)).thenReturn(nuevoEnvio);
        Envio guardado = envioService.guardar(nuevoEnvio);
        assertNotNull(guardado);
        assertEquals("Calle Nueva 456", guardado.getDireccionDestino());
        assertEquals("Valparaíso", guardado.getCiudad());
        assertEquals("Valparaíso", guardado.getRegion());
        assertEquals("2340000", guardado.getCodigoPostal());
        assertEquals("Pendiente", guardado.getEstado());
        assertEquals("Normal", guardado.getMetodoEnvio());
        assertEquals(LocalDate.of(2025, 7, 1), guardado.getFechaEnvio());
        assertEquals(LocalDate.of(2025, 7, 3), guardado.getFechaEntregaEstimada());
        assertEquals(3L, guardado.getId());
    }
}