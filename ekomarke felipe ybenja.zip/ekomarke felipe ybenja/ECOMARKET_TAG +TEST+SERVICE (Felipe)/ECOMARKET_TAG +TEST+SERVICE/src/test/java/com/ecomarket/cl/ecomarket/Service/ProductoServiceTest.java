package com.ecomarket.cl.ecomarket.Service;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import com.ecomarket.cl.ecomarket.model.Producto;
import com.ecomarket.cl.ecomarket.repository.ProductoRepository;
import com.ecomarket.cl.ecomarket.service.ProductoService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;



import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;



public class ProductoServiceTest {



@Mock
private ProductoRepository productoRepository;

@InjectMocks
private ProductoService productoService;

private Producto producto;

@BeforeEach
void setUp() {
    MockitoAnnotations.openMocks(this);
    producto = new Producto();
    producto.setId(1L);
    producto.setNombre("Papas Fritas");
    producto.setPrecio(1000.0);
    producto.setStock(50);
}

@Test
void testObtenerTodos() {
    when(productoRepository.findAll()).thenReturn(List.of(producto));
    List<Producto> productos = productoService.obtenerTodos();
    assertEquals(1, productos.size());
    assertEquals("Papas Fritas", productos.get(0).getNombre());
}

@Test
void testObtenerPorId() {
    when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
    Optional<Producto> result = productoService.obtenerPorId(1L);
    assertTrue(result.isPresent());
    assertEquals("Papas Fritas", result.get().getNombre());
}

@Test
void testGuardar() {
    when(productoRepository.save(producto)).thenReturn(producto);
    Producto guardado = productoService.guardar(producto);
    assertNotNull(guardado);
    assertEquals("Papas Fritas", guardado.getNombre());
}

@Test
void testEliminar() {
    doNothing().when(productoRepository).deleteById(1L);
    productoService.eliminar(1L);
    verify(productoRepository, times(1)).deleteById(1L);
}

}