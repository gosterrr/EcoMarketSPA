package com.ecomarket.cl.ecomarket.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class CuponDescuento {

    @Id
    private String codigo;
    private double descuento;
    private boolean utilizado;

    public CuponDescuento() {}

    public CuponDescuento(String codigo, double descuento) throws Exception {
        setCodigo(codigo);
        setDescuento(descuento);
        this.utilizado = false;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) throws Exception {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new Exception("El código del cupón no puede estar vacío.");
        }

        if (!codigo.matches("^[a-zA-Z0-9]+$")) {
            throw new Exception("El código del cupón debe ser alfanumérico (sin espacios ni símbolos especiales).");
        }

        this.codigo = codigo;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) throws Exception {
        if (descuento <= 5 || descuento >= 100) {
            throw new Exception("El descuento debe estar entre 5 y 100.");
        }

        this.descuento = descuento;
    }

    public boolean isUtilizado() {
        return utilizado;
    }

    public void setUtilizado(boolean utilizado) {
        this.utilizado = utilizado;
    }
}
