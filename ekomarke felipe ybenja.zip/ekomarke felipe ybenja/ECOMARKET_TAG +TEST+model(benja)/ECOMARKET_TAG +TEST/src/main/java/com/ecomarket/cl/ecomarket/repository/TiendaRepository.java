package com.ecomarket.cl.ecomarket.repository;

import com.ecomarket.cl.ecomarket.model.Tienda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TiendaRepository extends JpaRepository<Tienda, Long> {}

