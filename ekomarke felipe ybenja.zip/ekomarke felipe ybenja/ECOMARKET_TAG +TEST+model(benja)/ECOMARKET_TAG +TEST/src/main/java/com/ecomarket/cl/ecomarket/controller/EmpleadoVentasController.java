package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.CuponDescuento;
import com.ecomarket.cl.ecomarket.model.EmpleadoVentas;
import com.ecomarket.cl.ecomarket.service.EmpleadoVentasService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;


@Tag(name = "EmpleadoVentas", description = "Operaciones relacionadas con los empleados de ventas")
@RestController
@RequestMapping("/api/empleado-ventas")
public class EmpleadoVentasController {

    @Autowired
    private EmpleadoVentasService empleadoVentasService;

    @GetMapping
    @Operation(summary = "Listar todos los empleados de ventas", description = "Obtiene una lista de todos los empleados de ventas registrados.")
    @ResponseStatus(HttpStatus.OK)
    public List<EmpleadoVentas> listar() {
        return empleadoVentasService.obtenerTodos();
    }

    @GetMapping("/{rut}")
    @Operation(summary = "Obtener empleado de ventas por RUT", description = "Obtiene un empleado de ventas específico por su RUT.")
    @ResponseStatus(HttpStatus.OK)
    public EmpleadoVentas obtener(@PathVariable String rut) {
    return empleadoVentasService.obtenerPorRut(rut)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Empleado de Ventas no encontrado con RUT: " + rut));
}


    @PostMapping
    @Operation(summary = "Crear un nuevo empleado de ventas", description = "Registra un nuevo empleado de ventas en el sistema.")
    @ResponseStatus(HttpStatus.CREATED)
    public EmpleadoVentas crear(@RequestBody EmpleadoVentas empleadoVentas) {
        return empleadoVentasService.guardar(empleadoVentas);
    }

    @PutMapping("/{rut}")
    @Operation(summary = "Actualizar empleado de ventas", description = "Actualiza los datos de un empleado de ventas existente.")
    @ResponseStatus(HttpStatus.OK)
    public EmpleadoVentas actualizar(@PathVariable String rut, @RequestBody EmpleadoVentas empleadoVentas)throws Exception {
        empleadoVentas.setRut(rut);
        return empleadoVentasService.guardar(empleadoVentas);
    }

    @DeleteMapping("/{rut}")
    @Operation(summary = "Eliminar empleado de ventas", description = "Elimina un empleado de ventas del sistema por su RUT.")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable String rut) {
        empleadoVentasService.eliminar(rut);
    }

    //para crear cupones
    @PostMapping("/{rut}/generar-cupon")
    @Operation(summary = "Generar cupón de descuento", description = "Genera un cupón de descuento para un empleado de ventas.")
    @ResponseStatus(HttpStatus.CREATED)
    public CuponDescuento generarCupon(@PathVariable String rut, @RequestParam String codigo, @RequestParam double descuento)throws Exception {

        return empleadoVentasService.generarCupon(codigo, descuento);
    }
}
