package com.ecomarket.cl.ecomarket.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@Entity
public class Envio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String direccionDestino;
    private String ciudad;
    private String region;
    private String codigoPostal;
    private String estado;
    private String metodoEnvio;
    private LocalDate fechaEnvio;
    private LocalDate fechaEntregaEstimada;

    // Estados válidos de ejemplo - ajusta si tienes otros
    private static final List<String> ESTADOS_VALIDOS = Arrays.asList(
        "Pendiente", "En camino", "Entregado", "Cancelado"
    );

    // Métodos de envío válidos de ejemplo
    private static final List<String> METODOS_ENVIO_VALIDOS = Arrays.asList(
        "Estándar", "Express", "Retiro en tienda"
    );

    public Envio() {}

    public Envio(String direccionDestino, String ciudad, String region, String codigoPostal,
                 String estado, String metodoEnvio, LocalDate fechaEnvio, LocalDate fechaEntregaEstimada) throws Exception {
        setDireccionDestino(direccionDestino);
        setCiudad(ciudad);
        setRegion(region);
        setCodigoPostal(codigoPostal);
        setEstado(estado);
        setMetodoEnvio(metodoEnvio);
        setFechaEnvio(fechaEnvio);
        setFechaEntregaEstimada(fechaEntregaEstimada);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDireccionDestino() {
        return direccionDestino;
    }

    public void setDireccionDestino(String direccionDestino) throws Exception {
        if (direccionDestino == null || direccionDestino.trim().isEmpty()) {
            throw new Exception("La dirección de destino no puede estar vacía.");
        }
        this.direccionDestino = direccionDestino.trim();
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) throws Exception {
        if (ciudad == null || ciudad.trim().isEmpty()) {
            throw new Exception("La ciudad no puede estar vacía.");
        }
        this.ciudad = ciudad.trim();
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) throws Exception {
        if (region == null || region.trim().isEmpty()) {
            throw new Exception("La región no puede estar vacía.");
        }
        this.region = region.trim();
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) throws Exception {
        if (codigoPostal == null || codigoPostal.trim().isEmpty()) {
            throw new Exception("El código postal no puede estar vacío.");
        }
        String cp = codigoPostal.trim();
        if (!cp.matches("\\d{7}")) { // 7 dígitos numéricos
            throw new Exception("El código postal debe tener 7 dígitos numéricos.");
        }
        this.codigoPostal = cp;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) throws Exception {
        if (estado == null || estado.trim().isEmpty()) {
            throw new Exception("El estado no puede estar vacío.");
        }
        String est = estado.trim();
        if (!ESTADOS_VALIDOS.contains(est)) {
            throw new Exception("Estado inválido. Debe ser uno de: " + String.join(", ", ESTADOS_VALIDOS));
        }
        this.estado = est;
    }

    public String getMetodoEnvio() {
        return metodoEnvio;
    }

    public void setMetodoEnvio(String metodoEnvio) throws Exception {
        if (metodoEnvio == null || metodoEnvio.trim().isEmpty()) {
            throw new Exception("El método de envío no puede estar vacío.");
        }
        String metodo = metodoEnvio.trim();
        if (!METODOS_ENVIO_VALIDOS.contains(metodo)) {
            throw new Exception("Método de envío inválido. Debe ser uno de: " + String.join(", ", METODOS_ENVIO_VALIDOS));
        }
        this.metodoEnvio = metodo;
    }

    public LocalDate getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(LocalDate fechaEnvio) throws Exception {
        if (fechaEnvio == null) {
            throw new Exception("La fecha de envío no puede ser nula.");
        }
        if (fechaEnvio.isAfter(LocalDate.now())) {
            throw new Exception("La fecha de envío no puede ser futura.");
        }
        this.fechaEnvio = fechaEnvio;
    }

    public LocalDate getFechaEntregaEstimada() {
        return fechaEntregaEstimada;
    }

    public void setFechaEntregaEstimada(LocalDate fechaEntregaEstimada) throws Exception {
        if (fechaEntregaEstimada == null) {
            throw new Exception("La fecha de entrega estimada no puede ser nula.");
        }
        if (fechaEnvio != null && fechaEntregaEstimada.isBefore(fechaEnvio)) {
            throw new Exception("La fecha de entrega estimada no puede ser anterior a la fecha de envío.");
        }
        this.fechaEntregaEstimada = fechaEntregaEstimada;
    }
}
