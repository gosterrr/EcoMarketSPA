package com.ecomarket.cl.ecomarket.model;

import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class EmpleadoVentas extends Usuario {

    private String turno;
    private int ventasRealizadas;

    @ManyToOne
    @JoinColumn(name = "tienda_id")
    private Tienda tienda;

    public EmpleadoVentas() {}

    public EmpleadoVentas(String rut, String nombre, String correo, String direccion, String telefono,
                          String turno, int ventasRealizadas) throws Exception {
        super(rut, nombre, correo, direccion, telefono);
        setTurno(turno);
        setVentasRealizadas(ventasRealizadas);
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) throws Exception {
        if (turno == null) {
            throw new Exception("El turno no puede ser nulo.");
        }

        String turnoNormalizado = turno.trim().toLowerCase();

        switch (turnoNormalizado) {
            case "mañana":
                this.turno = "Mañana";
                break;
            case "tarde":
                this.turno = "Tarde";
                break;
            default:
                throw new Exception("Turno inválido. Debe ser 'Mañana' o 'Tarde' (con o sin mayúsculas).");
        }
    }

    public int getVentasRealizadas() {
        return ventasRealizadas;
    }

    public void setVentasRealizadas(int ventasRealizadas) throws Exception {
        if (ventasRealizadas < 0) {
            throw new Exception("La cantidad de ventas realizadas no puede ser negativa.");
        }
        this.ventasRealizadas = ventasRealizadas;
    }

    public Tienda getTienda() {
        return tienda;
    }

    public void setTienda(Tienda tienda) {
        this.tienda = tienda;
    }
}
