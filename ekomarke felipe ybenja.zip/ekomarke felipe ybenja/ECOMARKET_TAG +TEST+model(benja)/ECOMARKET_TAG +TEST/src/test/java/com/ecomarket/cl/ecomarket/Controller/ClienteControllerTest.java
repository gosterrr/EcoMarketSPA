package com.ecomarket.cl.ecomarket.Controller;

import com.ecomarket.cl.ecomarket.controller.ClienteController;
import com.ecomarket.cl.ecomarket.model.Cliente;
import com.ecomarket.cl.ecomarket.service.ClienteService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ClienteController.class)
@AutoConfigureMockMvc(addFilters = false)
class ClienteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ClienteService clienteService;

    @Autowired
    private ObjectMapper objectMapper;

    private Cliente cliente;

    @BeforeEach
    void setUp() throws Exception{
        cliente = new Cliente();
        cliente.setRut("11111111-1");
        cliente.setNombre("Pedro");
        cliente.setCorreo("pedro@mail.com");
        cliente.setDireccion("Calle Real 456");
        cliente.setTelefono("987654321");
        // No seteamos cliente.setCarrito(...) para evitar ciclos de serialización
    }

    @Test
    void testListar() throws Exception {
        when(clienteService.obtenerTodos()).thenReturn(List.of(cliente));

        mockMvc.perform(get("/api/clientes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].rut").value("11111111-1"))
                .andExpect(jsonPath("$[0].nombre").value("Pedro"));
    }

    @Test
    void testObtener_ClienteExiste() throws Exception {
        when(clienteService.obtenerPorRut("11111111-1")).thenReturn(Optional.of(cliente));

        mockMvc.perform(get("/api/clientes/11111111-1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rut").value("11111111-1"))
                .andExpect(jsonPath("$.nombre").value("Pedro"));
    }

    @Test
    void testObtener_ClienteNoExiste() throws Exception {
        when(clienteService.obtenerPorRut("22222222-2")).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/clientes/22222222-2"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testCrear() throws Exception {
        when(clienteService.guardar(any(Cliente.class))).thenReturn(cliente);

        mockMvc.perform(post("/api/clientes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(cliente)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.rut").value("11111111-1"))
                .andExpect(jsonPath("$.nombre").value("Pedro"));
    }

    @Test
    void testActualizar() throws Exception {
        when(clienteService.guardar(any(Cliente.class))).thenReturn(cliente);

        mockMvc.perform(put("/api/clientes/11111111-1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(cliente)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rut").value("11111111-1"))
                .andExpect(jsonPath("$.nombre").value("Pedro"));
    }

    @Test
    void testEliminar() throws Exception {
        doNothing().when(clienteService).eliminar("11111111-1");

        mockMvc.perform(delete("/api/clientes/11111111-1"))
                .andExpect(status().isNoContent());
    }

    @Test
    void testActualizarDireccion() throws Exception {
        doNothing().when(clienteService).actualizarDireccion("11111111-1", "Nueva Direccion");

        mockMvc.perform(put("/api/clientes/11111111-1/direccion")
                .param("nuevaDireccion", "Nueva Direccion"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetDetallesCliente() throws Exception {
        doNothing().when(clienteService).getDetallesCliente("11111111-1");

        mockMvc.perform(get("/api/clientes/11111111-1/detalles"))
                .andExpect(status().isOk());
    }

    @Test
    void testVerCarrito() throws Exception {
        doNothing().when(clienteService).verCarrito("11111111-1");

        mockMvc.perform(get("/api/clientes/11111111-1/carrito"))
                .andExpect(status().isOk());
    }

    @Test
    void testRealizarPedido() throws Exception {
        doNothing().when(clienteService).realizarPedido("11111111-1");

        mockMvc.perform(post("/api/clientes/11111111-1/pedido"))
                .andExpect(status().isCreated());
    }

    @Test
    void testObtener_ExcepcionInterna() throws Exception {
        when(clienteService.obtenerPorRut("11111111-1"))
                .thenThrow(new RuntimeException("Error inesperado"));

        mockMvc.perform(get("/api/clientes/11111111-1"))
                .andExpect(status().isInternalServerError());
    }

    @Test
    void testCrear_ExcepcionInterna() throws Exception {
        when(clienteService.guardar(any(Cliente.class)))
                .thenThrow(new RuntimeException("Error inesperado al crear cliente"));

        mockMvc.perform(post("/api/clientes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(cliente)))
                .andExpect(status().isInternalServerError());
    }
}