package com.ecomarket.cl.ecomarket.model;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class ProductoTest {

    @Test
    public void testConstructorValido() throws Exception {
        Producto p = new Producto("Manzana", 1200, 10);
        assertEquals("Manzana", p.getNombre());
        assertEquals(1200, p.getPrecio());
        assertEquals(10, p.getStock());
    }

    @Test
    public void testPrecioNegativoLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Producto("Pera", -5, 10);
        });
        assertTrue(ex.getMessage().toLowerCase().contains("precio no puede ser negativo"));
    }

    @Test
    public void testStockNegativoLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Producto("Pera", 5, -1);
        });
        assertTrue(ex.getMessage().toLowerCase().contains("stock no puede ser negativo"));
    }
}
    