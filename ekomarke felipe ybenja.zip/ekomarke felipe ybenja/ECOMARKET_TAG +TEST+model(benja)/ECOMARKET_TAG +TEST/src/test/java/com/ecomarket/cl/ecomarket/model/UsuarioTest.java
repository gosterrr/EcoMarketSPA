package com.ecomarket.cl.ecomarket.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class UsuarioTest {

    @Test
    public void testConstructorValido() throws Exception {
        Usuario u = new Usuario("12345678-9", "Juan", "juan@mail.com", "Calle 123", "987654321");
        assertEquals("12345678-9", u.getRut());
        assertEquals("Juan", u.getNombre());
        assertEquals("juan@mail.com", u.getCorreo());
        assertEquals("Calle 123", u.getDireccion());
        assertEquals("987654321", u.getTelefono());
    }

    @Test
    public void testRutMuyCortoLanzaExcepcion() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Usuario("123", "Juan", "juan@mail.com", "Calle", "987654321");
        });
        assertTrue(ex.getMessage().contains("RUT debe tener entre 9 y 12"));
    }

    @Test
    public void testCorreoInvalidoLanzaExcepcion() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Usuario("12345678-9", "Juan", "correomal@", "Calle", "987654321");
        });
        assertTrue(ex.getMessage().contains("correo debe contener"));
    }

    @Test
    public void testTelefonoIncorrectoLanzaExcepcion() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Usuario("12345678-9", "Juan", "correo@mail.cl", "Calle", "12345abc");
        });
        assertTrue(ex.getMessage().contains("teléfono debe contener exactamente 9 dígitos"));
    }

    @Test
    public void testSettersFuncionanCorrectamente() throws Exception {
        Usuario u = new Usuario();
        u.setRut("12345678-9");
        u.setNombre("Ana");
        u.setCorreo("ana@mail.cl");
        u.setDireccion("Otra calle 456");
        u.setTelefono("912345678");

        assertEquals("12345678-9", u.getRut());
        assertEquals("Ana", u.getNombre());
        assertEquals("ana@mail.cl", u.getCorreo());
        assertEquals("Otra calle 456", u.getDireccion());
        assertEquals("912345678", u.getTelefono());
    }
}
