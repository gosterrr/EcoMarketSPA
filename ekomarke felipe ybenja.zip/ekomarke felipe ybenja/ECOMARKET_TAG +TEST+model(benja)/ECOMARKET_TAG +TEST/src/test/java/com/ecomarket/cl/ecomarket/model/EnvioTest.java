package com.ecomarket.cl.ecomarket.model;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

public class EnvioTest {

    @Test
    public void testConstructorValido() throws Exception {
        Envio envio = new Envio(
            "Av. Siempre Viva 123",
            "Springfield",
            "Region Metropolitana",
            "1234567",
            "Pendiente",
            "Express",
            LocalDate.now().minusDays(1),
            LocalDate.now().plusDays(3)
        );
        assertEquals("Pendiente", envio.getEstado());
        assertEquals("Express", envio.getMetodoEnvio());
    }

    @Test
    public void testCodigoPostalInvalidoLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Envio("Dir", "Ciudad", "Region", "1234A67", "Pendiente", "Express", LocalDate.now(), LocalDate.now().plusDays(1));
        });
        assertTrue(ex.getMessage().toLowerCase().contains("código postal"));
    }

    @Test
    public void testEstadoInvalidoLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Envio("Dir", "Ciudad", "Region", "1234567", "ErrorEstado", "Express", LocalDate.now(), LocalDate.now().plusDays(1));
        });
        assertTrue(ex.getMessage().toLowerCase().contains("estado inválido"));
    }

    @Test
    public void testMetodoEnvioInvalidoLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Envio("Dir", "Ciudad", "Region", "1234567", "Pendiente", "Rapido", LocalDate.now(), LocalDate.now().plusDays(1));
        });
        assertTrue(ex.getMessage().toLowerCase().contains("método de envío inválido"));
    }

    @Test
    public void testFechaEnvioFuturaLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Envio("Dir", "Ciudad", "Region", "1234567", "Pendiente", "Express", LocalDate.now().plusDays(1), LocalDate.now().plusDays(2));
        });
        assertTrue(ex.getMessage().toLowerCase().contains("fecha de envío no puede ser futura"));
    }

    @Test
    public void testFechaEntregaAntesEnvioLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Envio("Dir", "Ciudad", "Region", "1234567", "Pendiente", "Express", LocalDate.now(), LocalDate.now().minusDays(1));
        });
        assertTrue(ex.getMessage().toLowerCase().contains("fecha de entrega estimada no puede ser anterior"));
    }
}
