package com.ecomarket.cl.ecomarket.Repository;

import com.ecomarket.cl.ecomarket.model.Envio;
import com.ecomarket.cl.ecomarket.repository.EnvioRepository;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class EnvioRepositoryTest {

    @Autowired
    private EnvioRepository envioRepository;

    @Test
    @DisplayName("Debe guardar un envío y luego buscarlo por ID")
    void testGuardarYBuscarPorId() {
        Envio envio = new Envio();
        

        envioRepository.save(envio);

        Optional<Envio> encontrado = envioRepository.findById(envio.getId());
        assertThat(encontrado).isPresent();
        assertThat(encontrado.get().getId()).isEqualTo(envio.getId());
    }

    @Test
    @DisplayName("Debe listar todos los envíos")
    void testListarTodos() {
        Envio envio1 = new Envio();
        Envio envio2 = new Envio();
      

        envioRepository.save(envio1);
        envioRepository.save(envio2);

        List<Envio> lista = envioRepository.findAll();
        assertThat(lista).hasSizeGreaterThanOrEqualTo(2);
    }

    @Test
    @DisplayName("Debe eliminar un envío por su ID")
    void testEliminarPorId() {
        Envio envio = new Envio();
        envioRepository.save(envio);

        Long id = envio.getId();
        assertThat(envioRepository.findById(id)).isPresent();

        envioRepository.deleteById(id);

        assertThat(envioRepository.findById(id)).isNotPresent();
    }
}
