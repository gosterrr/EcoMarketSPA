package com.ecomarket.cl.ecomarket.Service;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import com.ecomarket.cl.ecomarket.model.Usuario;
import com.ecomarket.cl.ecomarket.repository.UsuarioRepository;
import com.ecomarket.cl.ecomarket.service.UsuarioService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;


public class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioService usuarioService;

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        usuario = new Usuario();
        usuario.setRut("12345678-9");
        usuario.setNombre("Juan Perez");
        usuario.setCorreo("juan@example.com");
        usuario.setDireccion("Calle Falsa 123");
        usuario.setTelefono("987654321");
    }

    @Test
    void testObtenerTodos() {
        when(usuarioRepository.findAll()).thenReturn(List.of(usuario));
        List<Usuario> usuarios = usuarioService.obtenerTodos();
        assertEquals(1, usuarios.size());
        Usuario u = usuarios.get(0);
        assertEquals("Juan Perez", u.getNombre());
        assertEquals("juan@example.com", u.getCorreo());
        assertEquals("Calle Falsa 123", u.getDireccion());
        assertEquals("987654321", u.getTelefono());
        assertEquals("12345678-9", u.getRut());
    }

    @Test
    void testObtenerPorRut() {
        when(usuarioRepository.findById("12345678-9")).thenReturn(Optional.of(usuario));
        Optional<Usuario> result = usuarioService.obtenerPorRut("12345678-9");
        assertTrue(result.isPresent());
        Usuario u = result.get();
        assertEquals("Juan Perez", u.getNombre());
        assertEquals("juan@example.com", u.getCorreo());
        assertEquals("Calle Falsa 123", u.getDireccion());
        assertEquals("987654321", u.getTelefono());
        assertEquals("12345678-9", u.getRut());
    }

    @Test
    void testGuardar() {
        when(usuarioRepository.save(usuario)).thenReturn(usuario);
        Usuario guardado = usuarioService.guardar(usuario);
        assertNotNull(guardado);
        assertEquals("Juan Perez", guardado.getNombre());
        assertEquals("juan@example.com", guardado.getCorreo());
        assertEquals("Calle Falsa 123", guardado.getDireccion());
        assertEquals("987654321", guardado.getTelefono());
        assertEquals("12345678-9", guardado.getRut());
    }

    @Test
    void testEliminar() {
        doNothing().when(usuarioRepository).deleteById("12345678-9");
        usuarioService.eliminar("12345678-9");
        verify(usuarioRepository, times(1)).deleteById("12345678-9");
    }

    @Test
    void testObtenerPorRutNoExistente() {
        when(usuarioRepository.findById("00000000-0")).thenReturn(Optional.empty());
        Optional<Usuario> result = usuarioService.obtenerPorRut("00000000-0");
        assertFalse(result.isPresent());
    }

    @Test
    void testObtenerTodosVacio() {
        when(usuarioRepository.findAll()).thenReturn(List.of());
        List<Usuario> usuarios = usuarioService.obtenerTodos();
        assertTrue(usuarios.isEmpty());
    }

    @Test
    void testGuardarUsuarioConTodosLosAtributos() {
        Usuario nuevoUsuario = new Usuario("11111111-1", "Ana Lopez", "ana@example.com", "Av. Siempre Viva 742", "123123123");
        when(usuarioRepository.save(nuevoUsuario)).thenReturn(nuevoUsuario);
        Usuario guardado = usuarioService.guardar(nuevoUsuario);
        assertNotNull(guardado);
        assertEquals("11111111-1", guardado.getRut());
        assertEquals("Ana Lopez", guardado.getNombre());
        assertEquals("ana@example.com", guardado.getCorreo());
        assertEquals("Av. Siempre Viva 742", guardado.getDireccion());
        assertEquals("123123123", guardado.getTelefono());
    }
}