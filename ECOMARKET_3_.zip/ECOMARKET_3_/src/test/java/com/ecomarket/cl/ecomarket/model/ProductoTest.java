package com.ecomarket.cl.ecomarket.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ProductoTest {

    @Test
    public void testConstructorValido() throws Exception {
        Producto producto = new Producto("Manzana", 1000, 10);
        assertEquals("Manzana", producto.getNombre());
        assertEquals(1000, producto.getPrecio());
        assertEquals(10, producto.getStock());
    }

    @Test
    public void testPrecioNegativoLanzaExcepcion() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Producto("Manzana", -500, 10);
        });
        assertTrue(ex.getMessage().toLowerCase().contains("precio no puede ser negativo"));
    }

    @Test
    public void testStockNegativoLanzaExcepcion() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Producto("Manzana", 1000, -2);
        });
        assertTrue(ex.getMessage().toLowerCase().contains("stock no puede ser negativo"));
    }

    @Test
    public void testSetPrecioNegativoLanzaExcepcion() throws Exception {
        Producto producto = new Producto("Manzana", 1000, 10);
        Exception ex = assertThrows(Exception.class, () -> {
            producto.setPrecio(-1);
        });
        assertTrue(ex.getMessage().toLowerCase().contains("precio no puede ser negativo"));
    }

    @Test
    public void testSetStockNegativoLanzaExcepcion() throws Exception {
        Producto producto = new Producto("Manzana", 1000, 10);
        Exception ex = assertThrows(Exception.class, () -> {
            producto.setStock(-1);
        });
        assertTrue(ex.getMessage().toLowerCase().contains("stock no puede ser negativo"));
    }
}