package com.ecomarket.cl.ecomarket.Service;

import com.ecomarket.cl.ecomarket.model.Cliente;
import com.ecomarket.cl.ecomarket.repository.ClienteRepository;
import com.ecomarket.cl.ecomarket.service.ClienteService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ClienteServiceTest {

    @Mock
    private ClienteRepository clienteRepository;

    @InjectMocks
    private ClienteService clienteService;

    private Cliente cliente;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        cliente = new Cliente();
        cliente.setRut("12345678-9");
        cliente.setNombre("Juan Pérez");
        cliente.setCorreo("juan@example.com");
        cliente.setTelefono("987654321");
        cliente.setDireccion("Calle Falsa 123");
        cliente.setDireccionEnvio("Calle Envío 456");
    }

    @Test
    void testObtenerTodos() {
        when(clienteRepository.findAll()).thenReturn(List.of(cliente));
        List<Cliente> clientes = clienteService.obtenerTodos();
        assertEquals(1, clientes.size());
        assertEquals("Juan Pérez", clientes.get(0).getNombre());
    }

    @Test
    void testObtenerPorRut_Existe() {
        when(clienteRepository.findById("12345678-9")).thenReturn(Optional.of(cliente));
        Optional<Cliente> resultado = clienteService.obtenerPorRut("12345678-9");
        assertTrue(resultado.isPresent());
        assertEquals("Juan Pérez", resultado.get().getNombre());
    }

    @Test
    void testObtenerPorRut_NoExiste() {
when(clienteRepository.findById("99999999-9")).thenReturn(Optional.empty());
        clienteService.actualizarDireccion("99999999-9", "Dirección Fantasma");
        verify(clienteRepository, never()).save(any());
    }
}