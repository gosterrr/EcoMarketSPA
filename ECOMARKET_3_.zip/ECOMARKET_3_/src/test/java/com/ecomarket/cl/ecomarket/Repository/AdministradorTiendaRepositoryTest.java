package com.ecomarket.cl.ecomarket.Repository;

import com.ecomarket.cl.ecomarket.model.AdministradorTienda;
import com.ecomarket.cl.ecomarket.model.Tienda;
import com.ecomarket.cl.ecomarket.repository.AdministradorTiendaRepository;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class AdministradorTiendaRepositoryTest {

    @Autowired
    private AdministradorTiendaRepository administradorTiendaRepository;

    @Test
    @DisplayName("Debe guardar un administrador con todos sus atributos y relación con tienda")
    void testGuardarYVerificarAtributosYRelacionTienda() {
        // Crear administrador
        AdministradorTienda admin = new AdministradorTienda();
        admin.setRut("12345678-9");
        admin.setNombre("Sofía Herrera");
        admin.setCorreo("sofia.herrera@email.com");
        admin.setDireccion("Calle Central 123");
        admin.setTelefono("987654321");
        admin.setAccesoTotal(true);

       
        Tienda tienda = new Tienda();
        tienda.setId(1L);
        tienda.setDireccion("Calle Central 123");
        tienda.setAdministrador(admin);

        admin.setTienda(tienda); // Asignar la tienda al administrador

        administradorTiendaRepository.save(admin);

        Optional<AdministradorTienda> encontrado = administradorTiendaRepository.findById("12345678-9");

        assertThat(encontrado).isPresent();
        assertThat(encontrado.get().getNombre()).isEqualTo("Sofía Herrera");
        assertThat(encontrado.get().getCorreo()).isEqualTo("sofia.herrera@email.com");
        assertThat(encontrado.get().getDireccion()).isEqualTo("Calle Central 123");
        assertThat(encontrado.get().getTelefono()).isEqualTo("987654321");
        assertThat(encontrado.get().isAccesoTotal()).isTrue();
        assertThat(encontrado.get().getTienda()).isNotNull();
    }

    @Test
    @DisplayName("Debe guardar y luego eliminar un administrador por su RUT")
    void testGuardarYEliminarAdministrador() {
        AdministradorTienda admin = new AdministradorTienda();
        admin.setRut("11111111-1");
        admin.setNombre("Carlos Díaz");
        admin.setCorreo("carlos.diaz@email.com");
        admin.setDireccion("Calle Sur 456");
        admin.setTelefono("123123123");
        admin.setAccesoTotal(false);

        administradorTiendaRepository.save(admin);

        Optional<AdministradorTienda> encontrado = administradorTiendaRepository.findById("11111111-1");
        assertThat(encontrado).isPresent();

        administradorTiendaRepository.deleteById("11111111-1");

        Optional<AdministradorTienda> eliminado = administradorTiendaRepository.findById("11111111-1");
        assertThat(eliminado).isNotPresent();
    }

    @Test
    @DisplayName("Debe guardar varios administradores y encontrarlos todos")
    void testGuardarVariosYListarTodos() {
        AdministradorTienda admin1 = new AdministradorTienda();
        admin1.setRut("22222222-2");
        admin1.setNombre("María López");
        admin1.setCorreo("maria.lopez@email.com");
        admin1.setDireccion("Calle Norte 789");
        admin1.setTelefono("321321321");
        admin1.setAccesoTotal(true);

        AdministradorTienda admin2 = new AdministradorTienda();
        admin2.setRut("33333333-3");
        admin2.setNombre("Jorge Silva");
        admin2.setCorreo("jorge.silva@email.com");
        admin2.setDireccion("Calle Este 101");
        admin2.setTelefono("555555555");
        admin2.setAccesoTotal(false);

        administradorTiendaRepository.save(admin1);
        administradorTiendaRepository.save(admin2);

        List<AdministradorTienda> lista = administradorTiendaRepository.findAll();

        assertThat(lista).hasSize(2);
        assertThat(lista).anyMatch(a -> a.getRut().equals("22222222-2") && a.getNombre().equals("María López"));
        assertThat(lista).anyMatch(a -> a.getRut().equals("33333333-3") && a.getCorreo().equals("jorge.silva@email.com"));
    }
}
