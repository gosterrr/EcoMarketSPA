package com.ecomarket.cl.ecomarket.Controller;

import com.ecomarket.cl.ecomarket.controller.ProductoController;
import com.ecomarket.cl.ecomarket.model.Producto;
import com.ecomarket.cl.ecomarket.service.ProductoService;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(ProductoController.class)
@AutoConfigureMockMvc(addFilters = false)
public class ProductoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductoService productoService;

    @Autowired
    private ObjectMapper objectMapper;

    private Producto producto;

    @BeforeEach
public void setUp() throws Exception {
    producto = new Producto();
    producto.setId(1L);
    producto.setNombre("Producto Test");
    producto.setPrecio(1000.0); 
    producto.setStock(10);      
}

    @Test
    public void testListarProductos() throws Exception {
        when(productoService.obtenerTodos()).thenReturn(List.of(producto));

        mockMvc.perform(get("/api/productos"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id").value(1L))
            .andExpect(jsonPath("$[0].nombre").value("Producto Test"))
            .andExpect(jsonPath("$[0].precio").value(1000.0))
            .andExpect(jsonPath("$[0].stock").value(10));
    }

    @Test
    public void testObtenerProductoExiste() throws Exception {
        when(productoService.obtenerPorId(1L)).thenReturn(Optional.of(producto));

        mockMvc.perform(get("/api/productos/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(1L))
            .andExpect(jsonPath("$.nombre").value("Producto Test"))
            .andExpect(jsonPath("$.precio").value(1000.0))
            .andExpect(jsonPath("$.stock").value(10));
    }

    @Test
    public void testObtenerProductoNoExiste() throws Exception {
        when(productoService.obtenerPorId(1L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/productos/1"))
            .andExpect(status().isNotFound());
    }

    @Test
    public void testCrearProducto() throws Exception {
        when(productoService.guardar(any(Producto.class))).thenReturn(producto);

        mockMvc.perform(post("/api/productos")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(producto)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.id").value(1L))
            .andExpect(jsonPath("$.nombre").value("Producto Test"))
            .andExpect(jsonPath("$.precio").value(1000.0))
            .andExpect(jsonPath("$.stock").value(10));
    }

    @Test
    public void testActualizarProducto() throws Exception {
        when(productoService.guardar(any(Producto.class))).thenReturn(producto);

        mockMvc.perform(put("/api/productos/1")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(producto)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(1L))
            .andExpect(jsonPath("$.nombre").value("Producto Test"))
            .andExpect(jsonPath("$.precio").value(1000.0))
            .andExpect(jsonPath("$.stock").value(10));
    }

    @Test
    public void testEliminarProducto() throws Exception {
        doNothing().when(productoService).eliminar(1L);

        mockMvc.perform(delete("/api/productos/1"))
            .andExpect(status().isNoContent());
    }


    @Test
    public void testCrearProducto_StockNegativo_BadRequest() throws Exception {
    producto.setStock(-5); 

    mockMvc.perform(post("/api/productos")
            .contentType("application/json")
            .content(objectMapper.writeValueAsString(producto)))
        .andExpect(status().isBadRequest());
}

    @Test
    public void testActualizarProducto_NombreVacio_BadRequest() throws Exception {
        producto.setNombre("");  // Simula nombre vacío

        when(productoService.guardar(any(Producto.class)))
            .thenThrow(new RuntimeException("El nombre no puede estar vacío"));

        mockMvc.perform(put("/api/productos/1")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(producto)))
            .andExpect(status().isBadRequest());
    }


    @Test
    public void testEliminarProducto_NoExiste_NotFound() throws Exception {
        doThrow(new RuntimeException("Producto no encontrado"))
            .when(productoService).eliminar(999L);  // id inexistente

        mockMvc.perform(delete("/api/productos/999"))
            .andExpect(status().isNotFound());
    }



}