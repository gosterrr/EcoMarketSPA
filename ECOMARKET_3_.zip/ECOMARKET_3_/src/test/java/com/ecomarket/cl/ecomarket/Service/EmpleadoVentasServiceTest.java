package com.ecomarket.cl.ecomarket.Service;

import com.ecomarket.cl.ecomarket.model.CuponDescuento;
import com.ecomarket.cl.ecomarket.model.EmpleadoVentas;
import com.ecomarket.cl.ecomarket.repository.CuponDescuentoRepository;
import com.ecomarket.cl.ecomarket.repository.EmpleadoVentasRepository;
import com.ecomarket.cl.ecomarket.service.EmpleadoVentasService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class EmpleadoVentasServiceTest {

    @Mock
    private EmpleadoVentasRepository empleadoVentasRepository;

    @Mock
    private CuponDescuentoRepository cuponDescuentoRepository;

    @InjectMocks
    private EmpleadoVentasService empleadoVentasService;

    private EmpleadoVentas empleadoVentas;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        empleadoVentas = new EmpleadoVentas();
        empleadoVentas.setRut("77777777-7");
        empleadoVentas.setNombre("Lucia Torres");
        empleadoVentas.setCorreo("lucia.torres@email.com");
        empleadoVentas.setDireccion("Plaza Norte 321");
        empleadoVentas.setTelefono("777888999");
        empleadoVentas.setTurno("Noche");
        empleadoVentas.setVentasRealizadas(30);
    }

    @Test
    void testObtenerTodos() {
        when(empleadoVentasRepository.findAll()).thenReturn(List.of(empleadoVentas));
        List<EmpleadoVentas> empleados = empleadoVentasService.obtenerTodos();
        assertEquals(1, empleados.size());
        EmpleadoVentas e = empleados.get(0);
        assertEquals("Lucia Torres", e.getNombre());
        assertEquals("lucia.torres@email.com", e.getCorreo());
        assertEquals("Plaza Norte 321", e.getDireccion());
        assertEquals("777888999", e.getTelefono());
        assertEquals("77777777-7", e.getRut());
        assertEquals("Noche", e.getTurno());
        assertEquals(30, e.getVentasRealizadas());
    }

    @Test
    void testObtenerPorRut() {
        when(empleadoVentasRepository.findById("77777777-7")).thenReturn(Optional.of(empleadoVentas));
        Optional<EmpleadoVentas> result = empleadoVentasService.obtenerPorRut("77777777-7");
        assertTrue(result.isPresent());
        EmpleadoVentas e = result.get();
        assertEquals("Lucia Torres", e.getNombre());
        assertEquals("lucia.torres@email.com", e.getCorreo());
        assertEquals("Plaza Norte 321", e.getDireccion());
        assertEquals("777888999", e.getTelefono());
        assertEquals("77777777-7", e.getRut());
        assertEquals("Noche", e.getTurno());
        assertEquals(30, e.getVentasRealizadas());
    }

    @Test
    void testGuardar() {
        when(empleadoVentasRepository.save(empleadoVentas)).thenReturn(empleadoVentas);
        EmpleadoVentas guardado = empleadoVentasService.guardar(empleadoVentas);
        assertNotNull(guardado);
        assertEquals("Lucia Torres", guardado.getNombre());
        assertEquals("lucia.torres@email.com", guardado.getCorreo());
        assertEquals("Plaza Norte 321", guardado.getDireccion());
        assertEquals("777888999", guardado.getTelefono());
        assertEquals("77777777-7", guardado.getRut());
        assertEquals("Noche", guardado.getTurno());
        assertEquals(30, guardado.getVentasRealizadas());
    }

    @Test
    void testEliminar() {
        doNothing().when(empleadoVentasRepository).deleteById("77777777-7");
        empleadoVentasService.eliminar("77777777-7");
        verify(empleadoVentasRepository, times(1)).deleteById("77777777-7");
    }

    @Test
    void testObtenerPorRutNoExistente() {
        when(empleadoVentasRepository.findById("88888888-8")).thenReturn(Optional.empty());
        Optional<EmpleadoVentas> result = empleadoVentasService.obtenerPorRut("88888888-8");
        assertFalse(result.isPresent());
    }

    @Test
    void testObtenerTodosVacio() {
        when(empleadoVentasRepository.findAll()).thenReturn(List.of());
        List<EmpleadoVentas> empleados = empleadoVentasService.obtenerTodos();
        assertTrue(empleados.isEmpty());
    }

    @Test
    void testGuardarEmpleadoVentasConTodosLosAtributos() {
        EmpleadoVentas nuevoEmpleado = new EmpleadoVentas("99999999-9", "Valentin Rojas", "valentin.rojas@email.com", "Camino Real 654", "222333444", "Tarde", 45);
        when(empleadoVentasRepository.save(nuevoEmpleado)).thenReturn(nuevoEmpleado);
        EmpleadoVentas guardado = empleadoVentasService.guardar(nuevoEmpleado);
        assertNotNull(guardado);
        assertEquals("99999999-9", guardado.getRut());
        assertEquals("Valentin Rojas", guardado.getNombre());
        assertEquals("valentin.rojas@email.com", guardado.getCorreo());
        assertEquals("Camino Real 654", guardado.getDireccion());
        assertEquals("222333444", guardado.getTelefono());
        assertEquals("Tarde", guardado.getTurno());
        assertEquals(45, guardado.getVentasRealizadas());
    }

    @Test
    void testGenerarCupon() {
        CuponDescuento cupon = new CuponDescuento("PROMO20", 20.0);
        when(cuponDescuentoRepository.save(any(CuponDescuento.class))).thenReturn(cupon);
        CuponDescuento generado = empleadoVentasService.generarCupon("PROMO20", 20.0);
        assertNotNull(generado);
        assertEquals("PROMO20", generado.getCodigo());
        assertEquals(20.0, generado.getDescuento());
    }
}