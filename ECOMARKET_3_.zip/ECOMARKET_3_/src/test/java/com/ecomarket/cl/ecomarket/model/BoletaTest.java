package com.ecomarket.cl.ecomarket.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.List;

public class BoletaTest {

    @Test
    public void testConstructorValido() throws Exception {
        Producto p1 = new Producto("Manzana", 1200, 10);
        Producto p2 = new Producto("Pera", 800, 15);

        Boleta boleta = new Boleta(
            "12345678-9",
            List.of(p1, p2),
            3000,
            true,
            100
        );

        assertEquals("12345678-9", boleta.getClienteRut());
        assertEquals(2, boleta.getProductos().size());
        assertEquals(3000, boleta.getTotal());
        assertTrue(boleta.isCuponAplicado());
        assertEquals(100, boleta.getDescuentoAplicado());
        assertNotNull(boleta.getFecha());
    }

    @Test
    public void testRutInvalidoLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Boleta(
                "123",
                List.of(new Producto("Pera", 800, 15)),
                1500,
                false,
                0
            );
        });
        assertTrue(ex.getMessage().toLowerCase().contains("rut debe tener entre 9 y 12 caracteres"));
    }

    @Test
    public void testTotalNegativoLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Boleta(
                "12345678-9",
                List.of(new Producto("Pera", 800, 15)),
                -100,
                false,
                0
            );
        });
        assertTrue(ex.getMessage().toLowerCase().contains("total no puede ser negativo"));
    }

    @Test
    public void testProductosVacioLanza() {
        Exception ex = assertThrows(Exception.class, () -> {
            new Boleta(
                "12345678-9",
                List.of(),
                1000,
                false,
                0
            );
        });
        assertTrue(ex.getMessage().toLowerCase().contains("lista de productos no puede estar vacía"));
    }
}