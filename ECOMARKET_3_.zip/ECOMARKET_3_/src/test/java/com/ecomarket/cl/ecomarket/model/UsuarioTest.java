package com.ecomarket.cl.ecomarket.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class UsuarioTest {

    @Test
    public void testConstructorValido() {
        Usuario u = new Usuario("12345678-9", "Juan", "juan@mail.com", "Calle 123", "987654321");
        assertEquals("12345678-9", u.getRut());
        assertEquals("Juan", u.getNombre());
        assertEquals("juan@mail.com", u.getCorreo());
        assertEquals("Calle 123", u.getDireccion());
        assertEquals("987654321", u.getTelefono());
    }

    @Test
    public void testRutMuyCortoLanzaExcepcion() {
        assertThrows(Exception.class, () -> {
            new Usuario("123", "Juan", "juan@mail.com", "Calle", "987654321");
        });
    }

    @Test
    public void testCorreoInvalidoLanzaExcepcion() {
        assertThrows(Exception.class, () -> {
            new Usuario("12345678-9", "Juan", "correomal@", "Calle", "987654321");
        });
    }

    @Test
    public void testTelefonoIncorrectoLanzaExcepcion() {
        assertThrows(Exception.class, () -> {
            new Usuario("12345678-9", "Juan", "correo@mail.cl", "Calle", "12345abc");
        });
    }
}