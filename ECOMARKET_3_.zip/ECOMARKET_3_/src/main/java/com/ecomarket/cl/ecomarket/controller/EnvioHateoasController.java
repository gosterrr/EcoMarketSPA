package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.assemblers.EnvioModelAssembler;
import com.ecomarket.cl.ecomarket.model.Envio;
import com.ecomarket.cl.ecomarket.service.EnvioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Envio HATEOAS", description = "Operaciones HATEOAS para Envíos")
@RestController
@RequestMapping("/api/hateoas/envios")
public class EnvioHateoasController {

    @Autowired
    private EnvioService envioService;

    @Autowired
    private EnvioModelAssembler assembler;

    @GetMapping
    public CollectionModel<EntityModel<Envio>> listar() {
        List<EntityModel<Envio>> envios = envioService.obtenerTodos().stream()
            .map(assembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(envios,
            linkTo(methodOn(EnvioHateoasController.class).listar()).withSelfRel());
    }

    @GetMapping("/{id}")
    public EntityModel<Envio> obtener(@PathVariable Long id) {
        Envio envio = envioService.obtenerPorId(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Envío no encontrado con ID: " + id));

        return assembler.toModel(envio);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EntityModel<Envio> crear(@RequestBody Envio envio) {
        Envio creado = envioService.guardar(envio);
        return assembler.toModel(creado);
    }

    @PutMapping("/{id}")
    public EntityModel<Envio> actualizar(@PathVariable Long id, @RequestBody Envio envio) {
        envio.setId(id);
        Envio actualizado = envioService.guardar(envio);
        return assembler.toModel(actualizado);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) {
        envioService.eliminar(id);
    }
}

