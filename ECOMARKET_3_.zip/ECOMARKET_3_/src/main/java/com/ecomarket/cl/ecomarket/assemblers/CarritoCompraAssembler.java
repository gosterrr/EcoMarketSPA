package com.ecomarket.cl.ecomarket.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecomarket.cl.ecomarket.controller.CarritoCompraHateoasController;
import com.ecomarket.cl.ecomarket.model.CarritoCompra;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class CarritoCompraAssembler implements RepresentationModelAssembler<CarritoCompra, EntityModel<CarritoCompra>> {

    @Override
    public EntityModel<CarritoCompra> toModel(CarritoCompra carrito) {
        String rutCliente = carrito.getCliente().getRut();
        return EntityModel.of(carrito,
            linkTo(methodOn(CarritoCompraHateoasController.class).obtener(rutCliente)).withSelfRel(),
            linkTo(methodOn(CarritoCompraHateoasController.class).listar()).withRel("carritos"),
            linkTo(methodOn(CarritoCompraHateoasController.class).aplicarCupon(rutCliente, null)).withRel("aplicarCupon"),
            linkTo(methodOn(CarritoCompraHateoasController.class).realizarCompra(rutCliente)).withRel("realizarCompra")
        );
    }
}
