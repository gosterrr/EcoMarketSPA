package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.Boleta;
import com.ecomarket.cl.ecomarket.model.CarritoCompra;
import com.ecomarket.cl.ecomarket.model.Producto;
import com.ecomarket.cl.ecomarket.service.CarritoCompraService;
import com.ecomarket.cl.ecomarket.service.ProductoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Tag(name = "CarritoCompra", description = "Operaciones relacionadas con el carrito de compras")
@RestController
@RequestMapping("/api/carritos")
public class CarritoCompraController {

    @Autowired
    private CarritoCompraService carritoCompraService;

    @Autowired
    private ProductoService productoService;

    @GetMapping
    @Operation(summary = "Listar todos los carritos de compra", description = "Obtiene una lista de todos los carritos de compra registrados.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Carritos obtenidos correctamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public List<CarritoCompra> listar() {
        return carritoCompraService.obtenerTodos();
    }

    @GetMapping("/{rut}")
    @Operation(summary = "Obtener carrito de compra por RUT", description = "Obtiene un carrito de compra específico por el RUT del cliente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Carrito encontrado"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public CarritoCompra obtener(@PathVariable String rut) {
        return carritoCompraService.obtenerPorId(rut)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Carrito no encontrado"));
    }

    @PutMapping("/{rut}")
    @Operation(summary = "Actualizar carrito de compra", description = "Actualiza los datos de un carrito de compra existente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Carrito actualizado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public CarritoCompra actualizar(@PathVariable String rut, @RequestBody CarritoCompra carrito) {
        return carritoCompraService.guardar(carrito);
    }

    @DeleteMapping("/{rut}")
    @Operation(summary = "Eliminar carrito de compra", description = "Elimina un carrito de compra del sistema por el RUT del cliente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Carrito eliminado exitosamente"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable String rut) {
        carritoCompraService.eliminar(rut);
    }

    @PostMapping("/{clienteRut}/productos/{productoId}")
    @Operation(summary = "Agregar producto al carrito de compra", description = "Agrega un producto específico al carrito de compra del cliente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Producto agregado al carrito"),
        @ApiResponse(responseCode = "404", description = "Producto o carrito no encontrado"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public CarritoCompra agregarProducto(@PathVariable String clienteRut, @PathVariable Long productoId) {
        Producto producto = productoService.obtenerPorId(productoId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado"));

        return carritoCompraService.agregarProducto(clienteRut, producto.getId());
    }

    @PostMapping("/{clienteRut}/aplicar-cupon")
    @Operation(summary = "Aplicar cupón al carrito de compra", description = "Aplica un cupón de descuento al carrito de compra del cliente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Cupón aplicado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Cupón inválido o ya utilizado"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public CarritoCompra aplicarCupon(@PathVariable String clienteRut, @RequestParam String codigo) {
        try {
            return carritoCompraService.aplicarCuponAlCarrito(clienteRut, codigo);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    @PostMapping("/{clienteRut}/realizar-compra")
    @Operation(summary = "Realizar compra", description = "Finaliza la compra del carrito de compra del cliente y genera una boleta.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Compra realizada exitosamente y boleta generada"),
        @ApiResponse(responseCode = "400", description = "Carrito vacío o cupón inválido"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @ResponseStatus(HttpStatus.CREATED)
    public Boleta realizarCompra(@PathVariable String clienteRut) {
        try {
            return carritoCompraService.realizarCompra(clienteRut);
        } catch (RuntimeException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }
}
