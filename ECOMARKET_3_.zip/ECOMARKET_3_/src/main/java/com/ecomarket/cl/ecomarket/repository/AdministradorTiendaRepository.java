package com.ecomarket.cl.ecomarket.repository;

import com.ecomarket.cl.ecomarket.model.AdministradorTienda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdministradorTiendaRepository extends JpaRepository<AdministradorTienda, String> {}