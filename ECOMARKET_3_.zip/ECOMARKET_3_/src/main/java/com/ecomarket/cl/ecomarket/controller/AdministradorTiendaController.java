package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.AdministradorTienda;
import com.ecomarket.cl.ecomarket.model.EmpleadoVentas;
import com.ecomarket.cl.ecomarket.service.AdministradorTiendaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Tag(name = "AdministradorTienda", description = "Operaciones relacionadas con los administradores de tienda")
@RestController
@RequestMapping("/api/administrador-tienda")
public class AdministradorTiendaController {

    @Autowired
    private AdministradorTiendaService administradorTiendaService;

    @GetMapping
    @Operation(summary = "Listar todos los administradores de tienda", description = "Obtiene una lista de todos los administradores de tienda registrados.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public List<AdministradorTienda> listar() {
        return administradorTiendaService.obtenerTodos();
    }

    @GetMapping("/{rut}")
    @Operation(summary = "Obtener administrador de tienda por RUT", description = "Obtiene un administrador de tienda específico por su RUT.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Administrador encontrado"),
        @ApiResponse(responseCode = "404", description = "Administrador no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public AdministradorTienda obtener(@PathVariable String rut) {
        return administradorTiendaService.obtenerPorRut(rut)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Administrador no encontrado con RUT: " + rut));
    }

    @PostMapping
    @Operation(summary = "Crear un nuevo administrador de tienda", description = "Registra un nuevo administrador de tienda en el sistema.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Administrador creado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @ResponseStatus(HttpStatus.CREATED)
    public AdministradorTienda crear(@RequestBody AdministradorTienda administradorTienda) {
        return administradorTiendaService.guardar(administradorTienda);
    }

    @PutMapping("/{rut}")
    @Operation(summary = "Actualizar administrador de tienda", description = "Actualiza los datos de un administrador de tienda existente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Administrador actualizado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o RUT incorrecto"),
        @ApiResponse(responseCode = "404", description = "Administrador no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public AdministradorTienda actualizar(@PathVariable String rut, @RequestBody AdministradorTienda administradorTienda) {
        administradorTienda.setRut(rut);
        return administradorTiendaService.guardar(administradorTienda);
    }

    @DeleteMapping("/{rut}")
    @Operation(summary = "Eliminar administrador de tienda", description = "Elimina un administrador de tienda del sistema por su RUT.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Administrador eliminado exitosamente"),
        @ApiResponse(responseCode = "404", description = "Administrador no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable String rut) {
        administradorTiendaService.eliminar(rut);
    }

    @PostMapping("/{rutAdministrador}/asignar-empleado")
    @Operation(summary = "Asignar empleado a tienda", description = "Asigna un empleado de ventas a una tienda específica.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Empleado asignado exitosamente"),
        @ApiResponse(responseCode = "404", description = "Administrador o empleado no encontrado"),
        @ApiResponse(responseCode = "400", description = "Parámetros inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @ResponseStatus(HttpStatus.CREATED)
    public EmpleadoVentas asignarEmpleadoATienda(
            @PathVariable String rutAdministrador,
            @RequestParam String rutEmpleado,
            @RequestParam Long idTienda) {
        return administradorTiendaService.asignarEmpleadoATienda(rutAdministrador, rutEmpleado, idTienda);
    }
}
