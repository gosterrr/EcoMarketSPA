package com.ecomarket.cl.ecomarket.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;


import com.ecomarket.cl.ecomarket.controller.AdministradorTiendaHateoasController;
import com.ecomarket.cl.ecomarket.model.AdministradorTienda;

import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Component;

@Component
public class AdministradorTiendaAssembler implements RepresentationModelAssembler<AdministradorTienda, EntityModel<AdministradorTienda>> {

    @Override
    public EntityModel<AdministradorTienda> toModel(AdministradorTienda admin) {
        return EntityModel.of(admin,
            linkTo(methodOn(AdministradorTiendaHateoasController.class).obtener(admin.getRut())).withSelfRel(),
            linkTo(methodOn(AdministradorTiendaHateoasController.class).listar()).withRel("administradores"),
            linkTo(methodOn(AdministradorTiendaHateoasController.class).asignarEmpleadoATienda(admin.getRut(), null, null)).withRel("asignarEmpleado")
        );
    }
}

