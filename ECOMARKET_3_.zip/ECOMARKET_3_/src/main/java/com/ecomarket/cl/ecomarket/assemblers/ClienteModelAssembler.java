package com.ecomarket.cl.ecomarket.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;


import com.ecomarket.cl.ecomarket.controller.ClienteHateoasController;
import com.ecomarket.cl.ecomarket.model.Cliente;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class ClienteModelAssembler implements RepresentationModelAssembler<Cliente, EntityModel<Cliente>> {

    @Override
    public EntityModel<Cliente> toModel(Cliente cliente) {
        return EntityModel.of(cliente,
            linkTo(methodOn(ClienteHateoasController.class).obtener(cliente.getRut())).withSelfRel(),
            linkTo(methodOn(ClienteHateoasController.class).listar()).withRel("clientes")
        );
    }
}
