package com.ecomarket.cl.ecomarket.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
public class Boleta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String clienteRut;
    private double total;
    private double descuentoAplicado;
    private boolean cuponAplicado;
    private LocalDateTime fecha;

    @ManyToMany(cascade = CascadeType.PERSIST)
    @JoinTable(
        name = "boleta_producto",
        joinColumns = @JoinColumn(name = "boleta_id"),
        inverseJoinColumns = @JoinColumn(name = "producto_id")
    )
    private List<Producto> productos;

    public Boleta() {}

    public Boleta(String clienteRut, List<Producto> productos, double total, boolean cuponAplicado, double descuentoAplicado) throws Exception {
        setClienteRut(clienteRut);
        setProductos(productos);
        setTotal(total);
        this.cuponAplicado = cuponAplicado;
        this.descuentoAplicado = descuentoAplicado;
        this.fecha = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public String getClienteRut() {
        return clienteRut;
    }

    public void setClienteRut(String clienteRut) throws Exception {
        if (clienteRut == null || clienteRut.length() < 9 || clienteRut.length() > 12) {
            throw new Exception("RUT debe tener entre 9 y 12 caracteres");
        }
        this.clienteRut = clienteRut;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) throws Exception {
        if (total < 0) {
            throw new Exception("Total no puede ser negativo");
        }
        this.total = total;
    }

    public boolean isCuponAplicado() {
        return cuponAplicado;
    }

    public void setCuponAplicado(boolean cuponAplicado) {
        this.cuponAplicado = cuponAplicado;
    }

    public double getDescuentoAplicado() {
        return descuentoAplicado;
    }

    public void setDescuentoAplicado(double descuentoAplicado) {
        this.descuentoAplicado = descuentoAplicado;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) throws Exception {
        if (productos == null || productos.isEmpty()) {
            throw new Exception("Lista de productos no puede estar vacía");
        }
        this.productos = productos;
    }
}
