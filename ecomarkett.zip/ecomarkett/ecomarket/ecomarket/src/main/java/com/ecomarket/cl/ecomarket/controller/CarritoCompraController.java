package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.CarritoCompra;
import com.ecomarket.cl.ecomarket.model.Producto;
import com.ecomarket.cl.ecomarket.service.CarritoCompraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/carritos")
public class CarritoCompraController {
    @Autowired
    private CarritoCompraService carritoCompraService;

    @GetMapping
    public List<CarritoCompra> listar() {
        return carritoCompraService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public Optional<CarritoCompra> obtener(@PathVariable Long id) {
        return carritoCompraService.obtenerPorId(id);
    }

    @PostMapping
    public CarritoCompra crear(@RequestBody CarritoCompra carrito) {
        return carritoCompraService.guardar(carrito);
    }

    @PutMapping("/{id}")
    public CarritoCompra actualizar(@PathVariable Long id, @RequestBody CarritoCompra carrito) {
        carrito.setId(id);
        return carritoCompraService.guardar(carrito);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        carritoCompraService.eliminar(id);
    }

    // Nuevo endpoint para agregar productos al carrito
    @PostMapping("/{carritoId}/productos/{productoId}")
    public CarritoCompra agregarProducto(@PathVariable Long carritoId, @PathVariable Long productoId) {
        // Se busca el producto, si existe
        Producto producto = new Producto(); // Aquí puedes obtener el producto desde la base de datos por su ID
        producto.setId(productoId); // Este es solo un ejemplo, necesitarías cargar el producto desde la base de datos

        // Llamar al servicio para agregar el producto al carrito
        return carritoCompraService.agregarProducto(carritoId, producto);
    }
}
