package com.ecomarket.cl.ecomarket.service;

import com.ecomarket.cl.ecomarket.model.CarritoCompra;
import com.ecomarket.cl.ecomarket.model.Producto;
import com.ecomarket.cl.ecomarket.repository.CarritoCompraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.List;

@Service
public class CarritoCompraService {
    @Autowired
    private CarritoCompraRepository carritoCompraRepository;

    // Obtener todos los carritos
    public List<CarritoCompra> obtenerTodos() {
        return carritoCompraRepository.findAll();
    }

    // Obtener un carrito por ID
    public Optional<CarritoCompra> obtenerPorId(Long id) {
        return carritoCompraRepository.findById(id);
    }

    // Guardar o actualizar un carrito
    public CarritoCompra guardar(CarritoCompra carrito) {
        return carritoCompraRepository.save(carrito);
    }

    // Eliminar un carrito
    public void eliminar(Long id) {
        carritoCompraRepository.deleteById(id);
    }

    // Agregar un producto al carrito
    public CarritoCompra agregarProducto(Long carritoId, Producto producto) {
        // Obtener el carrito por ID
        Optional<CarritoCompra> carritoOpt = carritoCompraRepository.findById(carritoId);
        if (carritoOpt.isPresent()) {
            CarritoCompra carrito = carritoOpt.get();
            carrito.getProductos().add(producto); // Agregar el producto al carrito
            return carritoCompraRepository.save(carrito); // Guardar el carrito actualizado
        }
        return null; // Si el carrito no existe, retornar null
    }
}
