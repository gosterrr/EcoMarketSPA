package com.ecomarket.cl.ecomarket.repository;

import com.ecomarket.cl.ecomarket.model.CarritoCompra;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarritoCompraRepository extends JpaRepository<CarritoCompra, Long> {
}

