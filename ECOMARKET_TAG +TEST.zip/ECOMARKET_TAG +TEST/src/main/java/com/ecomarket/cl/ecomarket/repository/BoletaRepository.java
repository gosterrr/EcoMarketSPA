package com.ecomarket.cl.ecomarket.repository;

import com.ecomarket.cl.ecomarket.model.Boleta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoletaRepository extends JpaRepository<Boleta, Long> {
}
