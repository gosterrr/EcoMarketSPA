package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.Usuario;
import com.ecomarket.cl.ecomarket.service.UsuarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Tag(name = "Usuario", description = "Operaciones relacionadas con los usuarios")
@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {
    @Autowired
    private UsuarioService usuarioService;

    @GetMapping
    @Operation(summary = "Listar todos los usuarios", description = "Obtiene una lista de todos los usuarios registrados.")
    @ResponseStatus(HttpStatus.OK)
    public List<Usuario> listar() { return usuarioService.obtenerTodos(); }

    @GetMapping("/{rut}")
    @Operation(summary = "Obtener usuario por RUT", description = "Obtiene un usuario específico por su RUT.")
    public Usuario obtener(@PathVariable String rut) {
    return usuarioService.obtenerPorRut(rut)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado con RUT: " + rut));
    }


    @PostMapping
    @Operation(summary = "Crear un nuevo usuario", description = "Registra un nuevo usuario en el sistema.")
    @ResponseStatus(HttpStatus.CREATED)
    public Usuario crear(@RequestBody Usuario usuario) { return usuarioService.guardar(usuario); }

    @PutMapping("/{rut}")
    @Operation(summary = "Actualizar usuario", description = "Actualiza los datos de un usuario existente.")
    @ResponseStatus(HttpStatus.OK)
public Usuario actualizar(@PathVariable String rut, @RequestBody Usuario usuario) {
    usuario.setRut(rut); 
    return usuarioService.guardar(usuario);
}

    @DeleteMapping("/{rut}")
    @Operation(summary = "Eliminar usuario", description = "Elimina un usuario del sistema por su RUT.")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable String rut) {
        usuarioService.eliminar(rut);
    }
}
