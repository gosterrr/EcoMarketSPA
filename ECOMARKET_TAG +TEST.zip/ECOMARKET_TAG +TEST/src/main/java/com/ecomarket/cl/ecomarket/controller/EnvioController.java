package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.Envio;
import com.ecomarket.cl.ecomarket.service.EnvioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;


@Tag(name = "Envio", description = "Operaciones relacionadas con los envíos")
@RestController
@RequestMapping("/api/envios")
public class EnvioController {
    @Autowired
    private EnvioService envioService;

    @GetMapping
    @Operation(summary = "Listar todos los envíos", description = "Obtiene una lista de todos los envíos registrados.")
    @ResponseStatus(HttpStatus.OK)
    public List<Envio> listar() { return envioService.obtenerTodos(); }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener envío por ID", description = "Obtiene un envío específico por su ID.")
    @ResponseStatus(HttpStatus.OK)
    public Envio obtener(@PathVariable Long id) {
    return envioService.obtenerPorId(id)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Envío no encontrado con ID: " + id));
}


    @PostMapping
    @Operation(summary = "Crear un nuevo envío", description = "Registra un nuevo envío en el sistema.")
    @ResponseStatus(HttpStatus.CREATED)
    public Envio crear(@RequestBody Envio envio) { return envioService.guardar(envio); }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar envío", description = "Actualiza los datos de un envío existente.")
    @ResponseStatus(HttpStatus.OK)
    public Envio actualizar(@PathVariable Long id, @RequestBody Envio envio) {
        envio.setId(id);
        return envioService.guardar(envio);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar envío", description = "Elimina un envío del sistema por su ID.")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) { envioService.eliminar(id); }
}
