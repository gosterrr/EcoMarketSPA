package com.ecomarket.cl.ecomarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
