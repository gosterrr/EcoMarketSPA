package com.ecomarket.cl.ecomarket.Controller;

import com.ecomarket.cl.ecomarket.controller.ClienteController;
import com.ecomarket.cl.ecomarket.model.Cliente;
import com.ecomarket.cl.ecomarket.service.ClienteService;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(ClienteController.class)
@AutoConfigureMockMvc(addFilters = false)
public class ClienteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ClienteService clienteService;

    @Autowired
    private ObjectMapper objectMapper;

    private Cliente cliente;

    @BeforeEach
    public void setUp() {
        cliente = new Cliente();
        cliente.setRut("12345678-9");
        cliente.setNombre("Cliente Test");
        cliente.setCorreo("cliente@mail.com");
        cliente.setDireccion("Calle Cliente 123");
        cliente.setTelefono("987654321");
        cliente.setDireccionEnvio("Direccion Envio 456");
    }

    @Test
    public void testListarClientes() throws Exception {
        when(clienteService.obtenerTodos()).thenReturn(List.of(cliente));

        mockMvc.perform(get("/api/clientes"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].rut").value("12345678-9"))
            .andExpect(jsonPath("$[0].nombre").value("Cliente Test"))
            .andExpect(jsonPath("$[0].correo").value("cliente@mail.com"))
            .andExpect(jsonPath("$[0].direccionEnvio").value("Direccion Envio 456"));
    }

    @Test
    public void testObtener_ClienteExiste() throws Exception {
        when(clienteService.obtenerPorRut("123")).thenReturn(Optional.of(cliente));

        mockMvc.perform(get("/api/clientes/123"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.rut").value("12345678-9"))
            .andExpect(jsonPath("$.nombre").value("Cliente Test"))
            .andExpect(jsonPath("$.correo").value("cliente@mail.com"));
    }

    @Test
    public void testObtener_ClienteNoExiste() throws Exception {
        when(clienteService.obtenerPorRut("123")).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/clientes/123"))
            .andExpect(status().isNotFound());
    }

    @Test
    public void testCrearCliente() throws Exception {
        when(clienteService.guardar(any(Cliente.class))).thenReturn(cliente);

        mockMvc.perform(post("/api/clientes")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(cliente)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.rut").value("12345678-9"))
            .andExpect(jsonPath("$.nombre").value("Cliente Test"))
            .andExpect(jsonPath("$.correo").value("cliente@mail.com"));
    }

    @Test
    public void testActualizarCliente() throws Exception {
        when(clienteService.guardar(any(Cliente.class))).thenReturn(cliente);

        mockMvc.perform(put("/api/clientes/12345678-9")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(cliente)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.rut").value("12345678-9"))
            .andExpect(jsonPath("$.nombre").value("Cliente Test"))
            .andExpect(jsonPath("$.correo").value("cliente@mail.com"));
    }

    @Test
    public void testEliminarCliente() throws Exception {
        doNothing().when(clienteService).eliminar("12345678-9");

        mockMvc.perform(delete("/api/clientes/12345678-9"))
            .andExpect(status().isNoContent());
    }

    @Test
    public void testActualizarDireccion() throws Exception {
        doNothing().when(clienteService).actualizarDireccion("12345678-9", "Nueva Direccion");

        mockMvc.perform(put("/api/clientes/12345678-9/direccion")
                .param("nuevaDireccion", "Nueva Direccion"))
            .andExpect(status().isOk());
    }

    @Test
    public void testGetDetallesCliente() throws Exception {
        doNothing().when(clienteService).getDetallesCliente("12345678-9");

        mockMvc.perform(get("/api/clientes/12345678-9/detalles"))
            .andExpect(status().isOk());
    }

    @Test
    public void testVerCarrito() throws Exception {
        doNothing().when(clienteService).verCarrito("12345678-9");

        mockMvc.perform(get("/api/clientes/12345678-9/carrito"))
            .andExpect(status().isOk());
    }

    @Test
    public void testRealizarPedido() throws Exception {
        doNothing().when(clienteService).realizarPedido("12345678-9");

        mockMvc.perform(post("/api/clientes/12345678-9/pedido"))
            .andExpect(status().isCreated());
    }
}