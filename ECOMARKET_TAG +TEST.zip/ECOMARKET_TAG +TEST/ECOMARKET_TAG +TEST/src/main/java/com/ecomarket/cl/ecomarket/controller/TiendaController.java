package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.Tienda;
import com.ecomarket.cl.ecomarket.service.TiendaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import com.ecomarket.cl.ecomarket.service.AdministradorTiendaService;
import com.ecomarket.cl.ecomarket.model.AdministradorTienda;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Tag(name = "Tienda", description = "Operaciones relacionadas con las tiendas")
@RestController
@RequestMapping("/api/tiendas")
public class TiendaController {

    @Autowired
    private TiendaService tiendaService;

    @Autowired
    private AdministradorTiendaService administradorTiendaService;

    @GetMapping
    @Operation(summary = "Listar todas las tiendas", description = "Obtiene una lista de todas las tiendas registradas.")
    @ResponseStatus(HttpStatus.OK)
    public List<Tienda> listar() {
        return tiendaService.obtenerTodas();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener tienda por ID", description = "Obtiene una tienda específica por su ID.")
    @ResponseStatus(HttpStatus.OK)
    public Tienda obtener(@PathVariable Long id) {
    return tiendaService.obtenerPorId(id)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tienda no encontrada con ID: " + id));
}


    @PostMapping
    @Operation(summary = "Crear una nueva tienda", description = "Registra una nueva tienda en el sistema.")
    public Tienda crear(@RequestBody Tienda tienda) {
        return tiendaService.guardar(tienda);
    }

    @PostMapping("/crear-con-admin/{rut}")
    @Operation(summary = "Crear tienda con administrador", description = "Crea una nueva tienda y la asigna a un administrador existente por su RUT.")
    @ResponseStatus(HttpStatus.CREATED)
    public Tienda crearConAdmin(@RequestBody Tienda tienda, @PathVariable String rut) {
    AdministradorTienda admin = administradorTiendaService.obtenerPorRut(rut)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Administrador no encontrado con RUT: " + rut));
    tienda.setAdministrador(admin);
    return tiendaService.guardar(tienda);
}


    @PutMapping("/{id}")
    @Operation(summary = "Actualizar tienda", description = "Actualiza los datos de una tienda existente.")
    @ResponseStatus(HttpStatus.OK)
    public Tienda actualizar(@PathVariable Long id, @RequestBody Tienda tienda) {
        tienda.setId(id);
        return tiendaService.guardar(tienda);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar tienda", description = "Elimina una tienda del sistema por su ID.")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) {
        tiendaService.eliminar(id);
    }

    @PutMapping("/{id}/asignar-administrador/{rut}")
    @Operation(summary = "Asignar administrador a tienda", description = "Asigna un administrador a una tienda específica por su ID y RUT.")
    @ResponseStatus(HttpStatus.OK)
    public Tienda asignarAdministrador(@PathVariable Long id, @PathVariable String rut) {
    return tiendaService.asignarAdministrador(id, rut);
}

}
