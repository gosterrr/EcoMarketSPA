package com.ecomarket.cl.ecomarket.Controller;

import com.ecomarket.cl.ecomarket.controller.CarritoCompraController;
import com.ecomarket.cl.ecomarket.model.Boleta;
import com.ecomarket.cl.ecomarket.model.CarritoCompra;
import com.ecomarket.cl.ecomarket.model.Producto;
import com.ecomarket.cl.ecomarket.service.CarritoCompraService;
import com.ecomarket.cl.ecomarket.service.ProductoService;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(CarritoCompraController.class)
@AutoConfigureMockMvc(addFilters = false)
public class CarritoCompraControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CarritoCompraService carritoCompraService;

    @MockBean
    private ProductoService productoService;

    @Autowired
    private ObjectMapper objectMapper;

    private CarritoCompra carrito;
    private Producto producto;
    private Boleta boleta;

    @BeforeEach
    public void setUp() {
        carrito = new CarritoCompra();
        carrito.setId(1L);
        carrito.setTotalCarro(1000.0);

        producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Producto Test");
        producto.setPrecio(1000.0);
        producto.setStock(10);      

        boleta = new Boleta();
    }

    @Test
    public void testListarCarritos() throws Exception {
        when(carritoCompraService.obtenerTodos()).thenReturn(List.of(carrito));

        mockMvc.perform(get("/api/carritos"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id").value(carrito.getId()))
            .andExpect(jsonPath("$[0].totalCarro").value(carrito.getTotalCarro()));
    }

    @Test
    public void testObtenerCarritoExiste() throws Exception {
        when(carritoCompraService.obtenerPorId("123")).thenReturn(Optional.of(carrito));

        mockMvc.perform(get("/api/carritos/123"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(carrito.getId()))
            .andExpect(jsonPath("$.totalCarro").value(carrito.getTotalCarro()));
    }

    @Test
    public void testObtenerCarritoNoExiste() throws Exception {
        when(carritoCompraService.obtenerPorId("123")).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/carritos/123"))
            .andExpect(status().isNotFound());
    }

    @Test
    public void testActualizarCarrito() throws Exception {
        when(carritoCompraService.guardar(any(CarritoCompra.class))).thenReturn(carrito);

        mockMvc.perform(put("/api/carritos/123")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(carrito)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(carrito.getId()));
    }

    @Test
    public void testEliminarCarrito() throws Exception {
        doNothing().when(carritoCompraService).eliminar("123");

        mockMvc.perform(delete("/api/carritos/123"))
            .andExpect(status().isNoContent());
    }

    @Test
    public void testAgregarProducto() throws Exception {
        when(productoService.obtenerPorId(1L)).thenReturn(Optional.of(producto));
        when(carritoCompraService.agregarProducto("123", 1L)).thenReturn(carrito);

        mockMvc.perform(post("/api/carritos/123/productos/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(carrito.getId()));
    }

    @Test
    public void testAgregarProductoNoExiste() throws Exception {
        when(productoService.obtenerPorId(1L)).thenReturn(Optional.empty());

        mockMvc.perform(post("/api/carritos/123/productos/1"))
            .andExpect(status().isNotFound());
    }

    @Test
    public void testAplicarCupon() throws Exception {
        when(carritoCompraService.aplicarCuponAlCarrito("123", "CUPON123")).thenReturn(carrito);

        mockMvc.perform(post("/api/carritos/123/aplicar-cupon")
                .param("codigo", "CUPON123"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(carrito.getId()));
    }

    @Test
    public void testAplicarCuponError() throws Exception {
        when(carritoCompraService.aplicarCuponAlCarrito("123", "CUPON123"))
            .thenThrow(new RuntimeException("Cupón inválido"));

        mockMvc.perform(post("/api/carritos/123/aplicar-cupon")
                .param("codigo", "CUPON123"))
            .andExpect(status().isBadRequest());
    }

    @Test
    public void testRealizarCompra() throws Exception {
        when(carritoCompraService.realizarCompra("123")).thenReturn(boleta);

        mockMvc.perform(post("/api/carritos/123/realizar-compra"))
            .andExpect(status().isCreated());
    }

    @Test
    public void testRealizarCompraError() throws Exception {
        when(carritoCompraService.realizarCompra("123"))
            .thenThrow(new RuntimeException("No hay productos en el carrito"));

        mockMvc.perform(post("/api/carritos/123/realizar-compra"))
            .andExpect(status().isBadRequest());
    }


@Test
public void testAplicarCupon_CodigoInvalido_BadRequest() throws Exception {
    when(carritoCompraService.aplicarCuponAlCarrito("123", "CODIGO_INVALIDO"))
        .thenThrow(new RuntimeException("Cupón inválido"));

    mockMvc.perform(post("/api/carritos/123/aplicar-cupon")
            .param("codigo", "CODIGO_INVALIDO"))
        .andExpect(status().isBadRequest());
}



}
