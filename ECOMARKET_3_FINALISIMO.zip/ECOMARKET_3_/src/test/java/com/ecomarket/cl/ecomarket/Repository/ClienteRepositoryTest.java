package com.ecomarket.cl.ecomarket.Repository;

import com.ecomarket.cl.ecomarket.model.Cliente;
import com.ecomarket.cl.ecomarket.repository.ClienteRepository;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class ClienteRepositoryTest {

    @Autowired
    private ClienteRepository clienteRepository;

    @Test
    @DisplayName("Debe guardar un cliente y verificar que tiene un carrito asociado")
    void testGuardarYVerificarCarrito() {
        Cliente cliente = new Cliente();
        cliente.setRut("44444444-4");
        cliente.setNombre("Lucía Pérez");
        cliente.setCorreo("lucia.perez@email.com");
        cliente.setDireccion("");
        cliente.setTelefono("999888777");
        cliente.setDireccionEnvio("Calle Sur 123");

        clienteRepository.save(cliente);

        Optional<Cliente> encontrado = clienteRepository.findByRut("44444444-4");
        assertThat(encontrado).isPresent();

        Cliente clienteEncontrado = encontrado.get();
        assertThat(clienteEncontrado.getCarrito()).isNotNull();
        assertThat(clienteEncontrado.getCarrito().getCliente()).isEqualTo(clienteEncontrado);
    }

    @Test
    @DisplayName("Debe eliminar un cliente por su RUT")
    void testEliminarCliente() {
        Cliente cliente = new Cliente();
        cliente.setRut("");
        cliente.setNombre("Pedro Ramírez");
        cliente.setCorreo("pedro.ramirez@email.com");
        cliente.setDireccion("Calle Oeste 456");
        cliente.setTelefono("888777666");
        cliente.setDireccionEnvio("Calle Oeste 456");

        clienteRepository.save(cliente);
        assertThat(clienteRepository.findByRut("55555555-5")).isPresent();

        clienteRepository.deleteById("55555555-5");
        assertThat(clienteRepository.findByRut("55555555-5")).isNotPresent();
    }
}