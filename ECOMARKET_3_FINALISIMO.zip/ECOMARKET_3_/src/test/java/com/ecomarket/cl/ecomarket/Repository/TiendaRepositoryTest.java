package com.ecomarket.cl.ecomarket.Repository;

import com.ecomarket.cl.ecomarket.model.Tienda;
import com.ecomarket.cl.ecomarket.repository.TiendaRepository;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class TiendaRepositoryTest {

    @Autowired
    private TiendaRepository tiendaRepository;

    @Test
    @DisplayName("Debe guardar una tienda y luego encontrarla por su ID")
    void testGuardarYBuscarPorId() {
        Tienda tienda = new Tienda();
        

        tienda = tiendaRepository.save(tienda);

        Optional<Tienda> encontrado = tiendaRepository.findById(tienda.getId());
        assertThat(encontrado).isPresent();
        assertThat(encontrado.get().getId()).isEqualTo(tienda.getId());
    }

    @Test
    @DisplayName("Debe guardar varias tiendas y listarlas todas")
    void testGuardarVariosYListarTodos() {
        Tienda tienda1 = new Tienda();
        Tienda tienda2 = new Tienda();

        tiendaRepository.save(tienda1);
        tiendaRepository.save(tienda2);

        List<Tienda> lista = tiendaRepository.findAll();
        assertThat(lista).hasSize(2);
    }

    @Test
    @DisplayName("Debe eliminar una tienda por su ID")
    void testEliminarPorId() {
        Tienda tienda = new Tienda();
        tienda = tiendaRepository.save(tienda);
        Long id = tienda.getId();

        tiendaRepository.deleteById(id);

        Optional<Tienda> eliminado = tiendaRepository.findById(id);
        assertThat(eliminado).isNotPresent();
    }
}
