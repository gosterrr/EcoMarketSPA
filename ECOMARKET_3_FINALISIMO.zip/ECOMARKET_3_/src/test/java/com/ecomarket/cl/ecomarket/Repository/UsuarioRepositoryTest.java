package com.ecomarket.cl.ecomarket.Repository;

import com.ecomarket.cl.ecomarket.model.Usuario;
import com.ecomarket.cl.ecomarket.repository.UsuarioRepository;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class UsuarioRepositoryTest {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Test
    @DisplayName("Debe guardar un usuario y luego encontrarlo por su RUT")
    void testGuardarYBuscarPorRut() {
        Usuario usuario = new Usuario();
        usuario.setRut("77777777-7");
        usuario.setNombre("Ana Gómez");
        usuario.setCorreo("ana.gomez@email.com");
        usuario.setDireccion("Calle Falsa 123");
        usuario.setTelefono("555123456");

        usuario = usuarioRepository.save(usuario);

        Optional<Usuario> encontrado = usuarioRepository.findById("77777777-7");
        assertThat(encontrado).isPresent();
        assertThat(encontrado.get().getRut()).isEqualTo(usuario.getRut());
        assertThat(encontrado.get().getNombre()).isEqualTo("Ana Gómez");
    }

    @Test
    @DisplayName("Debe guardar varios usuarios y listarlos todos")
    void testGuardarVariosYListarTodos() {
        Usuario usuario1 = new Usuario();
        usuario1.setRut("88888888-8");
        usuario1.setNombre("Pedro Pérez");
        usuario1.setCorreo("pedro.perez@email.com");
        usuario1.setDireccion("Calle Norte 456");
        usuario1.setTelefono("555987654");

        Usuario usuario2 = new Usuario();
        usuario2.setRut("99999999-9");
        usuario2.setNombre("Laura Díaz");
        usuario2.setCorreo("laura.diaz@email.com");
        usuario2.setDireccion("Calle Sur 789");
        usuario2.setTelefono("555654321");

        usuarioRepository.save(usuario1);
        usuarioRepository.save(usuario2);

        List<Usuario> lista = usuarioRepository.findAll();
        assertThat(lista).hasSize(2);
        assertThat(lista).anyMatch(u -> u.getRut().equals("88888888-8") && u.getNombre().equals("Pedro Pérez"));
        assertThat(lista).anyMatch(u -> u.getRut().equals("99999999-9") && u.getNombre().equals("Laura Díaz"));
    }

    @Test
    @DisplayName("Debe eliminar un usuario por su RUT")
    void testEliminarPorRut() {
        Usuario usuario = new Usuario();
        usuario.setRut("66666666-6");
        usuario.setNombre("Carlos Morales");
        usuario.setCorreo("carlos.morales@email.com");
        usuario.setDireccion("Calle Este 321");
        usuario.setTelefono("555123789");

        usuario = usuarioRepository.save(usuario);
        String rut = usuario.getRut();

        usuarioRepository.deleteById(rut);

        Optional<Usuario> eliminado = usuarioRepository.findById(rut);
        assertThat(eliminado).isNotPresent();
    }
}
