package com.ecomarket.cl.ecomarket.Controller;

import com.ecomarket.cl.ecomarket.controller.UsuarioController;
import com.ecomarket.cl.ecomarket.model.Usuario;
import com.ecomarket.cl.ecomarket.service.UsuarioService;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(UsuarioController.class)
@AutoConfigureMockMvc(addFilters = false)
public class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @Autowired
    private ObjectMapper objectMapper;

    private Usuario usuario;

    @BeforeEach
public void setUp() {
    usuario = new Usuario();
    usuario.setRut("12345678-9");
    usuario.setNombre("XD");
    usuario.setCorreo("XD@mail.com");
    usuario.setDireccion("Calle Falsa 123");    
    usuario.setTelefono("123456789");
}

    @Test
public void testGetAllUsuarios() throws Exception {
    when(usuarioService.obtenerTodos()).thenReturn(List.of(usuario));

    mockMvc.perform(get("/api/usuarios"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$[0].rut").value("12345678-9"))
        .andExpect(jsonPath("$[0].nombre").value("XD"))
        .andExpect(jsonPath("$[0].correo").value("XD@mail.com"))
        .andExpect(jsonPath("$[0].direccion").value("Calle Falsa 123"))
        .andExpect(jsonPath("$[0].telefono").value("123456789"));
}

    @Test
public void testObtener_UsuarioExiste() throws Exception {
    when(usuarioService.obtenerPorRut("123")).thenReturn(Optional.of(usuario));

    mockMvc.perform(get("/api/usuarios/123"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.rut").value("12345678-9"))
            .andExpect(jsonPath("$.nombre").value("XD"))
            .andExpect(jsonPath("$.correo").value("XD@mail.com"));
}

@Test
public void testObtener_UsuarioNoExiste() throws Exception {
    when(usuarioService.obtenerPorRut("123")).thenReturn(Optional.empty());

    mockMvc.perform(get("/api/usuarios/123"))
            .andExpect(status().isNotFound());
}

@Test
public void testCrear() throws Exception {
    when(usuarioService.guardar(any(Usuario.class))).thenReturn(usuario);

    mockMvc.perform(post("/api/usuarios")
            .contentType("application/json")
            .content(objectMapper.writeValueAsString(usuario)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.rut").value("12345678-9"))
            .andExpect(jsonPath("$.nombre").value("XD"))
            .andExpect(jsonPath("$.correo").value("XD@mail.com"));
}

@Test
public void testActualizar() throws Exception {
    when(usuarioService.guardar(any(Usuario.class))).thenReturn(usuario);

    mockMvc.perform(put("/api/usuarios/12345678-9")
            .contentType("application/json")
            .content(objectMapper.writeValueAsString(usuario)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.rut").value("12345678-9"))
            .andExpect(jsonPath("$.nombre").value("XD"))
            .andExpect(jsonPath("$.correo").value("XD@mail.com"));
}

    @Test
    public void testEliminar() throws Exception {
        doNothing().when(usuarioService).eliminar("12345678-9");

        mockMvc.perform(delete("/api/usuarios/12345678-9"))
                .andExpect(status().isNoContent());
    }

    @Test
    public void testCrearUsuario_NombreVacio_BadRequest() throws Exception {
        usuario.setNombre("");

        when(usuarioService.guardar(any(Usuario.class)))
            .thenThrow(new RuntimeException("El nombre no puede estar vacío"));

        mockMvc.perform(post("/api/usuarios")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(usuario)))
            .andExpect(status().isBadRequest());
    }

    @Test
    public void testActualizarUsuario_NoExiste_NotFound() throws Exception {
        when(usuarioService.guardar(any(Usuario.class)))
            .thenThrow(new RuntimeException("Usuario no encontrado"));

        mockMvc.perform(put("/api/usuarios/99999999-9")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(usuario)))
            .andExpect(status().isNotFound());
    }

    @Test
public void testEliminarUsuario_NoExiste_NotFound() throws Exception {
    doThrow(new RuntimeException("Usuario no encontrado"))
        .when(usuarioService).eliminar("99999999-9");

    mockMvc.perform(delete("/api/usuarios/99999999-9"))
        .andExpect(status().isNotFound());
}



}