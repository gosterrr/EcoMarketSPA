package com.ecomarket.cl.ecomarket.Controller;

import com.ecomarket.cl.ecomarket.controller.EmpleadoVentasController;
import com.ecomarket.cl.ecomarket.model.CuponDescuento;
import com.ecomarket.cl.ecomarket.model.EmpleadoVentas;
import com.ecomarket.cl.ecomarket.service.EmpleadoVentasService;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(EmpleadoVentasController.class)
@AutoConfigureMockMvc(addFilters = false)
public class EmpleadoVentasControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EmpleadoVentasService empleadoVentasService;

    @Autowired
    private ObjectMapper objectMapper;

    private EmpleadoVentas empleadoVentas;
    private CuponDescuento cupon;

    @BeforeEach
    public void setUp() {
        empleadoVentas = new EmpleadoVentas();
        empleadoVentas.setRut("12345678-9");
        empleadoVentas.setNombre("Empleado Test");
        empleadoVentas.setCorreo("empleado@mail.com");
        empleadoVentas.setDireccion("Calle Empleado 123");
        empleadoVentas.setTelefono("987654321");
        empleadoVentas.setTurno("Mañana");
        empleadoVentas.setVentasRealizadas(10);

        cupon = new CuponDescuento();
        cupon.setCodigo("CUPON123");
        cupon.setDescuento(20.0);
    }

    @Test
    public void testListarEmpleados() throws Exception {
        when(empleadoVentasService.obtenerTodos()).thenReturn(List.of(empleadoVentas));

        mockMvc.perform(get("/api/empleado-ventas"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].rut").value("12345678-9"));
    }

    @Test
    public void testObtenerEmpleadoExiste() throws Exception {
        when(empleadoVentasService.obtenerPorRut("123")).thenReturn(Optional.of(empleadoVentas));

        mockMvc.perform(get("/api/empleado-ventas/123"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.rut").value("12345678-9"));
    }



    @Test
    public void testCrearEmpleado() throws Exception {
        when(empleadoVentasService.guardar(any(EmpleadoVentas.class))).thenReturn(empleadoVentas);

        mockMvc.perform(post("/api/empleado-ventas")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(empleadoVentas)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.rut").value("12345678-9"));
    }

    @Test
    public void testCrearEmpleado_DatosInvalidos() throws Exception {
        when(empleadoVentasService.guardar(any(EmpleadoVentas.class))).thenThrow(new IllegalArgumentException("Datos inválidos"));

        mockMvc.perform(post("/api/empleado-ventas")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(empleadoVentas)))
            .andExpect(status().isBadRequest())
            .andExpect(status().reason("Datos inválidos"));
    }

    @Test
    public void testActualizarEmpleado() throws Exception {
        when(empleadoVentasService.guardar(any(EmpleadoVentas.class))).thenReturn(empleadoVentas);

        mockMvc.perform(put("/api/empleado-ventas/12345678-9")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(empleadoVentas)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.rut").value("12345678-9"));
    }

    @Test
    public void testActualizarEmpleado_ErrorInterno() throws Exception {
        when(empleadoVentasService.guardar(any(EmpleadoVentas.class))).thenThrow(new RuntimeException("Error inesperado"));

        mockMvc.perform(put("/api/empleado-ventas/12345678-9")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(empleadoVentas)))
            .andExpect(status().isInternalServerError());
    }

    @Test
    public void testEliminarEmpleado_SinErrores() throws Exception {
        doNothing().when(empleadoVentasService).eliminar("12345678-9");

        mockMvc.perform(delete("/api/empleado-ventas/12345678-9"))
            .andExpect(status().isNoContent());
    }

    @Test
    public void testEliminarEmpleado_RutInvalido() throws Exception {
        doThrow(new IllegalArgumentException("RUT inválido: 12345678-9")).when(empleadoVentasService).eliminar("12345678-9");

        mockMvc.perform(delete("/api/empleado-ventas/12345678-9"))
            .andExpect(status().isBadRequest())
            .andExpect(status().reason("RUT inválido: 12345678-9"));
    }

    @Test
    public void testEliminarEmpleado_NoEncontrado() throws Exception {
        doThrow(new RuntimeException("Empleado no encontrado")).when(empleadoVentasService).eliminar("12345678-9");

        mockMvc.perform(delete("/api/empleado-ventas/12345678-9"))
            .andExpect(status().isNotFound())
            .andExpect(status().reason("Empleado de ventas no encontrado con RUT: 12345678-9"));
    }

    @Test
    public void testGenerarCupon() throws Exception {
        when(empleadoVentasService.generarCupon("CUPON123", 20.0)).thenReturn(cupon);

        mockMvc.perform(post("/api/empleado-ventas/12345678-9/generar-cupon")
                .param("codigo", "CUPON123")
                .param("descuento", "20.0"))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.codigo").value("CUPON123"))
            .andExpect(jsonPath("$.descuento").value(20.0));
    }

    @Test
    public void testGenerarCupon_ErrorNegocio() throws Exception {
      
        when(empleadoVentasService.generarCupon("CUPON123", 20.0))
            .thenThrow(new IllegalArgumentException("Cupón inválido o ya usado"));

        mockMvc.perform(post("/api/empleado-ventas/12345678-9/generar-cupon")
                .param("codigo", "CUPON123")
                .param("descuento", "20.0"))
            .andExpect(status().isBadRequest())
            .andExpect(status().reason("Cupón inválido o ya usado"));
    }

    @Test
    public void testGenerarCupon_ErrorInterno() throws Exception {
       
        when(empleadoVentasService.generarCupon("CUPON123", 20.0))
            .thenThrow(new RuntimeException("Error interno"));

        mockMvc.perform(post("/api/empleado-ventas/12345678-9/generar-cupon")
                .param("codigo", "CUPON123")
                .param("descuento", "20.0"))
            .andExpect(status().isInternalServerError());
    }

}
