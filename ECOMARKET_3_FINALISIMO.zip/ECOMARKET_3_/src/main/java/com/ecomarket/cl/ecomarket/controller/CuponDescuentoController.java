package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.CuponDescuento;
import com.ecomarket.cl.ecomarket.service.CuponDescuentoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@Tag(name = "CuponDescuento", description = "Operaciones relacionadas con los cupones de descuento")
@RestController
@RequestMapping("/api/cupones-descuento")
public class CuponDescuentoController {

    @Autowired
    private CuponDescuentoService cuponDescuentoService;

    @GetMapping("/{codigo}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Obtener cupón de descuento por código", description = "Obtiene un cupón de descuento específico por su código.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Cupón encontrado correctamente"),
        @ApiResponse(responseCode = "404", description = "Cupón no encontrado"),
        @ApiResponse(responseCode = "400", description = "Código de cupón inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public CuponDescuento obtener(@PathVariable String codigo) {
        return cuponDescuentoService.obtenerPorCodigo(codigo)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cupón no encontrado con código: " + codigo));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Crear un nuevo cupón de descuento", description = "Registra un nuevo cupón de descuento en el sistema.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Cupón creado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public CuponDescuento crear(@RequestBody CuponDescuento cupon) {
        return cuponDescuentoService.guardar(cupon);
    }

    @DeleteMapping("/{codigo}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Eliminar cupón de descuento", description = "Elimina un cupón de descuento del sistema por su código.")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Cupón eliminado correctamente"),
        @ApiResponse(responseCode = "404", description = "Cupón no encontrado"),
        @ApiResponse(responseCode = "400", description = "Código de cupón inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public void eliminar(@PathVariable String codigo) {
        cuponDescuentoService.eliminar(codigo);
    }
}
