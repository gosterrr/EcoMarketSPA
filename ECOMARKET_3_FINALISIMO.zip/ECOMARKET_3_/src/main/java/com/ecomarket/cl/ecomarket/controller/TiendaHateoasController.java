package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.assemblers.TiendaModelAssembler;
import com.ecomarket.cl.ecomarket.model.Tienda;
import com.ecomarket.cl.ecomarket.service.TiendaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import io.swagger.v3.oas.annotations.tags.Tag;
@Tag(name = "Tienda HATEOAS", description = "Operaciones HATEOAS para tiendas")
@RestController
@RequestMapping("/api/hateoas/tiendas")
public class TiendaHateoasController {

    @Autowired
    private TiendaService tiendaService;

    @Autowired
    private TiendaModelAssembler assembler;

    @GetMapping
    public CollectionModel<EntityModel<Tienda>> listar() {
        List<EntityModel<Tienda>> tiendas = tiendaService.obtenerTodas().stream()
            .map(assembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(tiendas,
            linkTo(methodOn(TiendaHateoasController.class).listar()).withSelfRel());
    }

    @GetMapping("/{id}")
    public EntityModel<Tienda> obtener(@PathVariable Long id) {
        Tienda tienda = tiendaService.obtenerPorId(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tienda no encontrada con ID: " + id));

        return assembler.toModel(tienda);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EntityModel<Tienda> crear(@RequestBody Tienda tienda) {
        Tienda creado = tiendaService.guardar(tienda);
        return assembler.toModel(creado);
    }

    @PutMapping("/{id}")
    public EntityModel<Tienda> actualizar(@PathVariable Long id, @RequestBody Tienda tienda) {
        tienda.setId(id);
        Tienda actualizado = tiendaService.guardar(tienda);
        return assembler.toModel(actualizado);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) {
        tiendaService.eliminar(id);
    }
}
