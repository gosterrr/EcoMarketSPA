package com.ecomarket.cl.ecomarket.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Envio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String direccionDestino;
    private String ciudad;
    private String region;
    private String codigoPostal;
    private String estado;
    private String metodoEnvio;
    private LocalDate fechaEnvio;
    private LocalDate fechaEntregaEstimada;

    public Envio() {}

    public Envio(String direccionDestino, String ciudad, String region, String codigoPostal,
                 String estado, String metodoEnvio, LocalDate fechaEnvio, LocalDate fechaEntregaEstimada) throws Exception {
        setDireccionDestino(direccionDestino);
        setCiudad(ciudad);
        setRegion(region);
        setCodigoPostal(codigoPostal);
        setEstado(estado);
        setMetodoEnvio(metodoEnvio);
        setFechaEnvio(fechaEnvio);
        setFechaEntregaEstimada(fechaEntregaEstimada);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDireccionDestino() {
        return direccionDestino;
    }

    public void setDireccionDestino(String direccionDestino) {
        this.direccionDestino = direccionDestino;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) throws Exception {
        if (codigoPostal == null || !codigoPostal.matches("\\d{7}")) {
            throw new Exception("Código postal debe contener exactamente 7 dígitos numéricos");
        }
        this.codigoPostal = codigoPostal;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) throws Exception {
        if (estado == null ||
            !(estado.equals("Pendiente") || estado.equals("Enviado") || estado.equals("Entregado"))) {
            throw new Exception("Estado inválido");
        }
        this.estado = estado;
    }

    public String getMetodoEnvio() {
        return metodoEnvio;
    }

    public void setMetodoEnvio(String metodoEnvio) throws Exception {
        if (metodoEnvio == null ||
            !(metodoEnvio.equals("Express") || metodoEnvio.equals("Normal"))) {
            throw new Exception("Método de envío inválido");
        }
        this.metodoEnvio = metodoEnvio;
    }

    public LocalDate getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(LocalDate fechaEnvio) throws Exception {
        if (fechaEnvio == null || fechaEnvio.isAfter(LocalDate.now())) {
            throw new Exception("Fecha de envío no puede ser futura");
        }
        this.fechaEnvio = fechaEnvio;
    }

    public LocalDate getFechaEntregaEstimada() {
        return fechaEntregaEstimada;
    }

    public void setFechaEntregaEstimada(LocalDate fechaEntregaEstimada) throws Exception {
        if (fechaEntregaEstimada == null || (this.fechaEnvio != null && fechaEntregaEstimada.isBefore(this.fechaEnvio))) {
            throw new Exception("Fecha de entrega estimada no puede ser anterior a la fecha de envío");
        }
        this.fechaEntregaEstimada = fechaEntregaEstimada;
    }
}