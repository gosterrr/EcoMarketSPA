package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.Cliente;
import com.ecomarket.cl.ecomarket.assemblers.ClienteModelAssembler;
import com.ecomarket.cl.ecomarket.service.ClienteService;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Tag(name = "Cliente HATEOAS", description = "Operaciones HATEOAS relacionadas con el cliente")
@RestController
@RequestMapping("/api/hateoas/clientes")
public class ClienteHateoasController {

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private ClienteModelAssembler assembler;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Listar todos los clientes", description = "Obtiene una lista de todos los clientes registrados.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Clientes obtenidos correctamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public CollectionModel<EntityModel<Cliente>> listar() {
        List<EntityModel<Cliente>> clientes = clienteService.obtenerTodos().stream()
            .map(assembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(clientes,
            linkTo(methodOn(ClienteHateoasController.class).listar()).withSelfRel());
    }

    @GetMapping("/{rut}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Obtener cliente por RUT", description = "Obtiene un cliente específico por su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Cliente encontrado"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public EntityModel<Cliente> obtener(@PathVariable String rut) {
        Cliente cliente = clienteService.obtenerPorRut(rut)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado con RUT: " + rut));
        return assembler.toModel(cliente);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Crear un nuevo cliente", description = "Registra un nuevo cliente en el sistema.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Cliente creado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public EntityModel<Cliente> crear(@RequestBody Cliente cliente) {
        Cliente nuevoCliente = clienteService.guardar(cliente);
        return assembler.toModel(nuevoCliente);
    }

    @PutMapping("/{rut}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Actualizar cliente", description = "Actualiza los datos de un cliente existente.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Cliente actualizado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o RUT incorrecto"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public EntityModel<Cliente> actualizar(@PathVariable String rut, @RequestBody Cliente cliente) {
        cliente.setRut(rut);
        Cliente actualizado = clienteService.guardar(cliente);
        return assembler.toModel(actualizado);
    }

    @DeleteMapping("/{rut}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Eliminar cliente", description = "Elimina un cliente del sistema por su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Cliente eliminado correctamente"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public void eliminar(@PathVariable String rut) {
        clienteService.eliminar(rut);
    }

    @PutMapping("/{rut}/direccion")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Actualizar dirección del cliente", description = "Actualiza la dirección de un cliente específico.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Dirección actualizada correctamente"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "400", description = "Parámetros inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public EntityModel<Cliente> actualizarDireccion(@PathVariable String rut, @RequestParam String nuevaDireccion) {
        clienteService.actualizarDireccion(rut, nuevaDireccion);
        Cliente clienteActualizado = clienteService.obtenerPorRut(rut)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado con RUT: " + rut));
        return assembler.toModel(clienteActualizado);
    }

    @PostMapping("/{rut}/pedido")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Realizar pedido del cliente", description = "Permite al cliente realizar un pedido utilizando su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Pedido realizado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o carrito vacío"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public EntityModel<Cliente> realizarPedido(@PathVariable String rut) {
        clienteService.realizarPedido(rut);
        Cliente cliente = clienteService.obtenerPorRut(rut)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado con RUT: " + rut));
        return assembler.toModel(cliente);
    }
}

