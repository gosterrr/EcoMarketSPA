package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.Tienda;
import com.ecomarket.cl.ecomarket.service.TiendaService;
import com.ecomarket.cl.ecomarket.service.AdministradorTiendaService;
import com.ecomarket.cl.ecomarket.model.AdministradorTienda;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Tag(name = "Tienda", description = "Operaciones relacionadas con las tiendas")
@RestController
@RequestMapping("/api/tiendas")
public class TiendaController {

    @Autowired
    private TiendaService tiendaService;

    @Autowired
    private AdministradorTiendaService administradorTiendaService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Listar todas las tiendas", description = "Obtiene una lista de todas las tiendas registradas.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de tiendas obtenida exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public List<Tienda> listar() {
        return tiendaService.obtenerTodas();
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Obtener tienda por ID", description = "Obtiene una tienda específica por su ID.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Tienda encontrada correctamente"),
        @ApiResponse(responseCode = "404", description = "Tienda no encontrada"),
        @ApiResponse(responseCode = "400", description = "ID inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public Tienda obtener(@PathVariable Long id) {
        return tiendaService.obtenerPorId(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tienda no encontrada con ID: " + id));
    }

    @PostMapping
    @Operation(summary = "Crear una nueva tienda", description = "Registra una nueva tienda en el sistema.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Tienda creada exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para crear la tienda"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public Tienda crear(@RequestBody Tienda tienda) {
        return tiendaService.guardar(tienda);
    }

    @PostMapping("/crear-con-admin/{rut}")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Crear tienda con administrador", description = "Crea una nueva tienda y la asigna a un administrador existente por su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Tienda creada con administrador asignado exitosamente"),
        @ApiResponse(responseCode = "404", description = "Administrador no encontrado"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public Tienda crearConAdmin(@RequestBody Tienda tienda, @PathVariable String rut) {
        AdministradorTienda admin = administradorTiendaService.obtenerPorRut(rut)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Administrador no encontrado con RUT: " + rut));
        tienda.setAdministrador(admin);
        return tiendaService.guardar(tienda);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Actualizar tienda", description = "Actualiza los datos de una tienda existente.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Tienda actualizada correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para actualizar la tienda"),
        @ApiResponse(responseCode = "404", description = "Tienda no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public Tienda actualizar(@PathVariable Long id, @RequestBody Tienda tienda) {
        tienda.setId(id);
        return tiendaService.guardar(tienda);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Eliminar tienda", description = "Elimina una tienda del sistema por su ID.")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Tienda eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Tienda no encontrada"),
        @ApiResponse(responseCode = "400", description = "ID inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public void eliminar(@PathVariable Long id) {
        tiendaService.eliminar(id);
    }

    @PutMapping("/{id}/asignar-administrador/{rut}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Asignar administrador a tienda", description = "Asigna un administrador a una tienda específica por su ID y RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Administrador asignado correctamente"),
        @ApiResponse(responseCode = "404", description = "Tienda o administrador no encontrados"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public Tienda asignarAdministrador(@PathVariable Long id, @PathVariable String rut) {
        return tiendaService.asignarAdministrador(id, rut);
    }
}
