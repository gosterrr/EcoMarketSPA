package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.assemblers.CarritoCompraAssembler;
import com.ecomarket.cl.ecomarket.model.CarritoCompra;
import com.ecomarket.cl.ecomarket.model.Producto;
import com.ecomarket.cl.ecomarket.model.Boleta;
import com.ecomarket.cl.ecomarket.service.CarritoCompraService;
import com.ecomarket.cl.ecomarket.service.ProductoService;

import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Tag(name = "Carrito Compra HATEOAS", description = "Operaciones HATEOAS relacionadas con el carrito de compra")
@RestController
@RequestMapping("/api/hateoas/carritos")
public class CarritoCompraHateoasController {

    @Autowired
    private CarritoCompraService carritoCompraService;

    @Autowired
    private ProductoService productoService;

    @Autowired
    private CarritoCompraAssembler carritoAssembler;

    @GetMapping
    public CollectionModel<EntityModel<CarritoCompra>> listar() {
        List<EntityModel<CarritoCompra>> carritos = carritoCompraService.obtenerTodos().stream()
            .map(carritoAssembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(carritos,
            linkTo(methodOn(CarritoCompraHateoasController.class).listar()).withSelfRel());
    }

    @GetMapping("/{rut}")
    public EntityModel<CarritoCompra> obtener(@PathVariable String rut) {
        CarritoCompra carrito = carritoCompraService.obtenerPorId(rut)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Carrito no encontrado"));

        return carritoAssembler.toModel(carrito);
    }

    @PutMapping("/{rut}")
    public EntityModel<CarritoCompra> actualizar(@PathVariable String rut, @RequestBody CarritoCompra carrito) {
        CarritoCompra actualizado = carritoCompraService.guardar(carrito);
        return carritoAssembler.toModel(actualizado);
    }

    @DeleteMapping("/{rut}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable String rut) {
        carritoCompraService.eliminar(rut);
    }

    @PostMapping("/{clienteRut}/productos/{productoId}")
    public EntityModel<CarritoCompra> agregarProducto(@PathVariable String clienteRut, @PathVariable Long productoId) {
        Producto producto = productoService.obtenerPorId(productoId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado"));

        CarritoCompra actualizado = carritoCompraService.agregarProducto(clienteRut, producto.getId());
        return carritoAssembler.toModel(actualizado);
    }

    @PostMapping("/{clienteRut}/aplicar-cupon")
    public EntityModel<CarritoCompra> aplicarCupon(@PathVariable String clienteRut, @RequestParam String codigo) {
        try {
            CarritoCompra actualizado = carritoCompraService.aplicarCuponAlCarrito(clienteRut, codigo);
            return carritoAssembler.toModel(actualizado);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    @PostMapping("/{clienteRut}/realizar-compra")
    @ResponseStatus(HttpStatus.CREATED)
    public Boleta realizarCompra(@PathVariable String clienteRut) {
        try {
            return carritoCompraService.realizarCompra(clienteRut);
        } catch (RuntimeException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }
}

