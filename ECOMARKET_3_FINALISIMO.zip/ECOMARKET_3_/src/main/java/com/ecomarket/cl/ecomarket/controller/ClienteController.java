package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.Cliente;
import com.ecomarket.cl.ecomarket.service.ClienteService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Tag(name = "Cliente", description = "Operaciones relacionadas con los clientes")
@RestController
@RequestMapping("/api/clientes")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Listar todos los clientes", description = "Obtiene una lista de todos los clientes registrados.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Clientes obtenidos correctamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public List<Cliente> listar() {
        try {
            return clienteService.obtenerTodos();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al obtener clientes");
        }
    }

    @GetMapping("/{rut}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Obtener cliente por RUT", description = "Obtiene un cliente específico por su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Cliente encontrado"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public Cliente obtener(@PathVariable String rut) {
        try {
            return clienteService.obtenerPorRut(rut)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado con RUT: " + rut));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "RUT inválido: " + rut);
        } catch (ResponseStatusException e) {
            throw e; 
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al obtener cliente");
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Crear un nuevo cliente", description = "Registra un nuevo cliente en el sistema.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Cliente creado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public Cliente crear(@RequestBody Cliente cliente) {
        try {
            return clienteService.guardar(cliente);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al crear cliente");
        }
    }

    @PutMapping("/{rut}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Actualizar cliente", description = "Actualiza los datos de un cliente existente.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Cliente actualizado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o RUT incorrecto"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public Cliente actualizar(@PathVariable String rut, @RequestBody Cliente cliente) {
        cliente.setRut(rut);
        try {
            // Suponiendo que guardar() actualiza si existe y crea si no
            return clienteService.guardar(cliente);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al actualizar cliente");
        }
    }

    @DeleteMapping("/{rut}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Eliminar cliente", description = "Elimina un cliente del sistema por su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Cliente eliminado correctamente"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public void eliminar(@PathVariable String rut) {
        try {
            clienteService.eliminar(rut);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "RUT inválido: " + rut);
        } catch (RuntimeException e) {
            // Distinguir si es porque no existe el cliente
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("no encontrado")) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado con RUT: " + rut);
            } else {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
        }
    }

    @PutMapping("/{rut}/direccion")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Actualizar dirección del cliente", description = "Actualiza la dirección de un cliente específico.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Dirección actualizada correctamente"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "400", description = "Parámetros inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public void actualizarDireccion(@PathVariable String rut, @RequestParam String nuevaDireccion) {
        try {
            clienteService.actualizarDireccion(rut, nuevaDireccion);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Datos inválidos para la dirección");
        } catch (RuntimeException e) {
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("no encontrado")) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado con RUT: " + rut);
            } else {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
        }
    }

    @GetMapping("/{rut}/detalles")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Obtener detalles del cliente", description = "Obtiene los detalles de un cliente específico por su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Detalles obtenidos correctamente"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public void getDetallesCliente(@PathVariable String rut) {
        try {
            clienteService.getDetallesCliente(rut);
        } catch (RuntimeException e) {
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("no encontrado")) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado con RUT: " + rut);
            } else {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
        }
    }

    @GetMapping("/{rut}/carrito")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Ver carrito de compra del cliente", description = "Muestra el carrito de compra del cliente por su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Carrito mostrado correctamente"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public void verCarrito(@PathVariable String rut) {
        try {
            clienteService.verCarrito(rut);
        } catch (RuntimeException e) {
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("no encontrado")) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado con RUT: " + rut);
            } else {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
        }
    }

    @PostMapping("/{rut}/pedido")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Realizar pedido del cliente", description = "Permite al cliente realizar un pedido utilizando su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Pedido realizado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o carrito vacío"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public void realizarPedido(@PathVariable String rut) {
        try {
            clienteService.realizarPedido(rut);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (RuntimeException e) {
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("no encontrado")) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado con RUT: " + rut);
            } else {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor");
        }
    }
}
