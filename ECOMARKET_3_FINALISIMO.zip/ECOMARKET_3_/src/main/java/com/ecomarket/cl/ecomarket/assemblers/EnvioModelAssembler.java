package com.ecomarket.cl.ecomarket.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.ecomarket.cl.ecomarket.controller.EnvioHateoasController;
import com.ecomarket.cl.ecomarket.model.Envio;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class EnvioModelAssembler implements RepresentationModelAssembler<Envio, EntityModel<Envio>> {

    @Override
    public EntityModel<Envio> toModel(Envio envio) {
        return EntityModel.of(envio,
            linkTo(methodOn(EnvioHateoasController.class).obtener(envio.getId())).withSelfRel(),
            linkTo(methodOn(EnvioHateoasController.class).listar()).withRel("envios")
        );
    }
}
