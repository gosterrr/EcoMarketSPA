package com.ecomarket.cl.ecomarket.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;


import com.ecomarket.cl.ecomarket.model.AdministradorTienda;
import com.ecomarket.cl.ecomarket.model.EmpleadoVentas;
import com.ecomarket.cl.ecomarket.service.AdministradorTiendaService;

import io.swagger.v3.oas.annotations.tags.Tag;

import com.ecomarket.cl.ecomarket.assemblers.AdministradorTiendaAssembler;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Tag(name = "Administrador Tienda HATEOAS", description = "Operaciones HATEOAS para Administradores de Tienda")
@RestController
@RequestMapping("/api/hateoas/administrador-tienda")
public class AdministradorTiendaHateoasController {

    @Autowired
    private AdministradorTiendaService administradorTiendaService;

    @Autowired
    private AdministradorTiendaAssembler assembler;

    @GetMapping
    public CollectionModel<EntityModel<AdministradorTienda>> listar() {
        List<EntityModel<AdministradorTienda>> administradores = administradorTiendaService.obtenerTodos()
            .stream()
            .map(assembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(administradores,
            linkTo(AdministradorTiendaHateoasController.class).withSelfRel());
    }

    @GetMapping("/{rut}")
    public EntityModel<AdministradorTienda> obtener(@PathVariable String rut) {
        AdministradorTienda admin = administradorTiendaService.obtenerPorRut(rut)
            .orElseThrow(() -> new RuntimeException("Administrador no encontrado con RUT: " + rut));
        return assembler.toModel(admin);
    }

    @PostMapping("/{rutAdministrador}/asignar-empleado")
    @ResponseStatus(HttpStatus.CREATED)
    public EntityModel<EmpleadoVentas> asignarEmpleadoATienda(
            @PathVariable String rutAdministrador,
            @RequestParam String rutEmpleado,
            @RequestParam Long idTienda) {
        EmpleadoVentas empleado = administradorTiendaService.asignarEmpleadoATienda(rutAdministrador, rutEmpleado, idTienda);
        return EntityModel.of(empleado);
    }
}

