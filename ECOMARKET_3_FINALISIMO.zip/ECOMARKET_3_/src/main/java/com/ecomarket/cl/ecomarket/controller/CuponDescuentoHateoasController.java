package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.assemblers.CuponDescuentoAssembler;
import com.ecomarket.cl.ecomarket.model.CuponDescuento;
import com.ecomarket.cl.ecomarket.service.CuponDescuentoService;

import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Tag(name = "Cupón descuento HATEOAS", description = "Operaciones HATEOAS para los cupones de descuento")
@RestController
@RequestMapping("/api/hateoas/cupones-descuento")
public class CuponDescuentoHateoasController {

    @Autowired
    private CuponDescuentoService cuponDescuentoService;

    @Autowired
    private CuponDescuentoAssembler cuponAssembler;

    @GetMapping
    public CollectionModel<EntityModel<CuponDescuento>> listar() {
        List<EntityModel<CuponDescuento>> cupones = cuponDescuentoService.obtenerTodos().stream()
            .map(cuponAssembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(cupones,
            linkTo(methodOn(CuponDescuentoHateoasController.class).listar()).withSelfRel());
    }

    @GetMapping("/{codigo}")
    public EntityModel<CuponDescuento> obtener(@PathVariable String codigo) {
        CuponDescuento cupon = cuponDescuentoService.obtenerPorCodigo(codigo)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cupón no encontrado con código: " + codigo));
        return cuponAssembler.toModel(cupon);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EntityModel<CuponDescuento> crear(@RequestBody CuponDescuento cupon) {
        CuponDescuento creado = cuponDescuentoService.guardar(cupon);
        return cuponAssembler.toModel(creado);
    }

    @DeleteMapping("/{codigo}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable String codigo) {
        cuponDescuentoService.eliminar(codigo);
    }
}
