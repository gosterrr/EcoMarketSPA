package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.Boleta;
import com.ecomarket.cl.ecomarket.model.CarritoCompra;
import com.ecomarket.cl.ecomarket.model.Producto;
import com.ecomarket.cl.ecomarket.service.CarritoCompraService;
import com.ecomarket.cl.ecomarket.service.ProductoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Tag(name = "CarritoCompra", description = "Operaciones relacionadas con el carrito de compras")
@RestController
@RequestMapping("/api/carritos")
public class CarritoCompraController {

    @Autowired
    private CarritoCompraService carritoCompraService;

    @Autowired
    private ProductoService productoService;

    @GetMapping
    @Operation(summary = "Listar todos los carritos de compra", description = "Obtiene una lista de todos los carritos de compra registrados.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Carritos obtenidos correctamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<List<CarritoCompra>> listar() {
        try {
            List<CarritoCompra> carritos = carritoCompraService.obtenerTodos();
            return ResponseEntity.ok(carritos);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{rut}")
    @Operation(summary = "Obtener carrito de compra por RUT", description = "Obtiene un carrito de compra específico por el RUT del cliente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Carrito encontrado"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<CarritoCompra> obtener(@PathVariable String rut) {
        try {
            return carritoCompraService.obtenerPorId(rut)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Carrito no encontrado"));
        } catch (ResponseStatusException ex) {
            throw ex;
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/{rut}")
    @Operation(summary = "Actualizar carrito de compra", description = "Actualiza los datos de un carrito de compra existente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Carrito actualizado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<CarritoCompra> actualizar(@PathVariable String rut, @RequestBody CarritoCompra carrito) {
        try {
            // Aquí ideal validar que el rut del path y del carrito coincidan, si aplica
            CarritoCompra actualizado = carritoCompraService.guardar(carrito);
            return ResponseEntity.ok(actualizado);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{rut}")
    @Operation(summary = "Eliminar carrito de compra", description = "Elimina un carrito de compra del sistema por el RUT del cliente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Carrito eliminado exitosamente"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<Void> eliminar(@PathVariable String rut) {
        try {
            carritoCompraService.eliminar(rut);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/{clienteRut}/productos/{productoId}")
    @Operation(summary = "Agregar producto al carrito de compra", description = "Agrega un producto específico al carrito de compra del cliente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Producto agregado al carrito"),
        @ApiResponse(responseCode = "404", description = "Producto o carrito no encontrado"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<CarritoCompra> agregarProducto(@PathVariable String clienteRut, @PathVariable Long productoId) {
        try {
            Producto producto = productoService.obtenerPorId(productoId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado"));

            CarritoCompra carritoActualizado = carritoCompraService.agregarProducto(clienteRut, producto.getId());
            return ResponseEntity.ok(carritoActualizado);
        } catch (ResponseStatusException ex) {
            throw ex;
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/{clienteRut}/aplicar-cupon")
    @Operation(summary = "Aplicar cupón al carrito de compra", description = "Aplica un cupón de descuento al carrito de compra del cliente.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Cupón aplicado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Cupón inválido o ya utilizado"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<CarritoCompra> aplicarCupon(@PathVariable String clienteRut, @RequestParam String codigo) {
        try {
            CarritoCompra carritoConCupon = carritoCompraService.aplicarCuponAlCarrito(clienteRut, codigo);
            return ResponseEntity.ok(carritoConCupon);
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/{clienteRut}/realizar-compra")
    @Operation(summary = "Realizar compra", description = "Finaliza la compra del carrito de compra del cliente y genera una boleta.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Compra realizada exitosamente y boleta generada"),
        @ApiResponse(responseCode = "400", description = "Carrito vacío o cupón inválido"),
        @ApiResponse(responseCode = "404", description = "Carrito no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<Boleta> realizarCompra(@PathVariable String clienteRut) {
        try {
            Boleta boleta = carritoCompraService.realizarCompra(clienteRut);
            return ResponseEntity.status(HttpStatus.CREATED).body(boleta);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
