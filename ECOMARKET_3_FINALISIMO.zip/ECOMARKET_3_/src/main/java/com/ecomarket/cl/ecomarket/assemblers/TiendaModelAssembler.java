package com.ecomarket.cl.ecomarket.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;


import com.ecomarket.cl.ecomarket.controller.TiendaHateoasController;
import com.ecomarket.cl.ecomarket.model.Tienda;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class TiendaModelAssembler implements RepresentationModelAssembler<Tienda, EntityModel<Tienda>> {

    @Override
    public EntityModel<Tienda> toModel(Tienda tienda) {
        return EntityModel.of(tienda,
            linkTo(methodOn(TiendaHateoasController.class).obtener(tienda.getId())).withSelfRel(),
            linkTo(methodOn(TiendaHateoasController.class).listar()).withRel("tiendas")
        );
    }
}

