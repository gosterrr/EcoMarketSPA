package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.assemblers.EmpleadoVentasModelAssembler;
import com.ecomarket.cl.ecomarket.model.CuponDescuento;
import com.ecomarket.cl.ecomarket.model.EmpleadoVentas;
import com.ecomarket.cl.ecomarket.service.EmpleadoVentasService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import io.swagger.v3.oas.annotations.tags.Tag;
@Tag(name = "Empleado Ventas HATEOAS", description = "Operaciones HATEOAS para Empleados de Ventas")
@RestController
@RequestMapping("/api/hateoas/empleado-ventas")
public class EmpleadoVentasHateoasController {

    @Autowired
    private EmpleadoVentasService empleadoVentasService;

    @Autowired
    private EmpleadoVentasModelAssembler assembler;

    @GetMapping
    public CollectionModel<EntityModel<EmpleadoVentas>> listar() {
        List<EntityModel<EmpleadoVentas>> empleados = empleadoVentasService.obtenerTodos().stream()
            .map(assembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(empleados,
            linkTo(methodOn(EmpleadoVentasHateoasController.class).listar()).withSelfRel());
    }

    @GetMapping("/{rut}")
    public EntityModel<EmpleadoVentas> obtener(@PathVariable String rut) {
        EmpleadoVentas empleado = empleadoVentasService.obtenerPorRut(rut)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Empleado de ventas no encontrado con RUT: " + rut));

        return assembler.toModel(empleado);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EntityModel<EmpleadoVentas> crear(@RequestBody EmpleadoVentas empleado) {
        EmpleadoVentas creado = empleadoVentasService.guardar(empleado);
        return assembler.toModel(creado);
    }

    @PutMapping("/{rut}")
    public EntityModel<EmpleadoVentas> actualizar(@PathVariable String rut, @RequestBody EmpleadoVentas empleado) {
        empleado.setRut(rut);
        EmpleadoVentas actualizado = empleadoVentasService.guardar(empleado);
        return assembler.toModel(actualizado);
    }

    @DeleteMapping("/{rut}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable String rut) {
        empleadoVentasService.eliminar(rut);
    }

    @PostMapping("/{rut}/generar-cupon")
    @ResponseStatus(HttpStatus.CREATED)
    public CuponDescuento generarCupon(@PathVariable String rut, @RequestParam String codigo, @RequestParam double descuento) {
        return empleadoVentasService.generarCupon(codigo, descuento);
    }
}
