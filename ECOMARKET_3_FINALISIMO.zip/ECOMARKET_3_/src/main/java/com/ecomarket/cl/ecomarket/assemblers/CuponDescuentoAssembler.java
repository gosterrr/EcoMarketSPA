package com.ecomarket.cl.ecomarket.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;


import com.ecomarket.cl.ecomarket.controller.CuponDescuentoHateoasController;
import com.ecomarket.cl.ecomarket.model.CuponDescuento;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class CuponDescuentoAssembler implements RepresentationModelAssembler<CuponDescuento, EntityModel<CuponDescuento>> {

    @Override
    public EntityModel<CuponDescuento> toModel(CuponDescuento cupon) {
        return EntityModel.of(cupon,
            linkTo(methodOn(CuponDescuentoHateoasController.class).obtener(cupon.getCodigo())).withSelfRel(),
            linkTo(CuponDescuentoHateoasController.class).slash(cupon.getCodigo()).withRel("eliminar")
        );
    }
}


