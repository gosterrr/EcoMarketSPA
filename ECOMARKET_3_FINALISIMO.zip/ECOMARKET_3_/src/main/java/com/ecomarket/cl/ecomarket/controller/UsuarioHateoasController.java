package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.assemblers.UsuarioAssembler;
import com.ecomarket.cl.ecomarket.model.Usuario;
import com.ecomarket.cl.ecomarket.service.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import io.swagger.v3.oas.annotations.tags.Tag;
@Tag(name = "Usuario HATEOAS", description = "Operaciones HATEOAS para usuarios")
@RestController
@RequestMapping("/api/hateoas/usuarios")
public class UsuarioHateoasController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private UsuarioAssembler usuarioAssembler;

    @GetMapping
    public CollectionModel<EntityModel<Usuario>> listar() {
        List<EntityModel<Usuario>> usuarios = usuarioService.obtenerTodos().stream()
            .map(usuarioAssembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(usuarios,
            linkTo(methodOn(UsuarioHateoasController.class).listar()).withSelfRel());
    }

    @GetMapping("/{rut}")
    public EntityModel<Usuario> obtener(@PathVariable String rut) {
        Usuario usuario = usuarioService.obtenerPorRut(rut)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado"));

        return usuarioAssembler.toModel(usuario);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EntityModel<Usuario> crear(@RequestBody Usuario usuario) throws Exception {
        Usuario creado = usuarioService.guardar(usuario);
        return usuarioAssembler.toModel(creado);
    }

    @PutMapping("/{rut}")
    public EntityModel<Usuario> actualizar(@PathVariable String rut, @RequestBody Usuario usuario)throws Exception {
        usuario.setRut(rut);
        Usuario actualizado = usuarioService.guardar(usuario);
        return usuarioAssembler.toModel(actualizado);
    }

    @DeleteMapping("/{rut}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable String rut) {
        usuarioService.eliminar(rut);
    }
}

