package com.ecomarket.cl.ecomarket.service;

import com.ecomarket.cl.ecomarket.model.Usuario;
import com.ecomarket.cl.ecomarket.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> obtenerPorRut(String rut) {
        return usuarioRepository.findById(rut);
    }

    public Usuario guardar(Usuario usuario) throws Exception {
        validarUsuario(usuario);
        return usuarioRepository.save(usuario);
    }

    public void eliminar(String rut) {
        usuarioRepository.deleteById(rut);
    }

    // Reglas de negocio con `throw new Exception`
    private void validarUsuario(Usuario usuario) throws Exception {
        if (usuario.getRut() == null || usuario.getRut().length() < 9 || usuario.getRut().length() > 12) {
            throw new Exception("El RUT debe tener entre 9 y 12 caracteres.");
        }

        if (usuario.getCorreo() == null || !usuario.getCorreo().contains("@")
                || !(usuario.getCorreo().endsWith(".com") || usuario.getCorreo().endsWith(".cl"))) {
            throw new Exception("El correo debe contener '@' y terminar en '.com' o '.cl'.");
        }

        if (usuario.getTelefono() == null || !usuario.getTelefono().matches("\\d{9}")) {
            throw new Exception("El teléfono debe contener exactamente 9 dígitos numéricos.");
        }

        if (usuario.getNombre() == null || usuario.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre no puede estar vacío.");
        }

        if (usuario.getDireccion() == null || usuario.getDireccion().trim().isEmpty()) {
            throw new Exception("La dirección no puede estar vacía.");
        }
    }
}

