package com.ecomarket.cl.ecomarket.controller;

import com.ecomarket.cl.ecomarket.model.CuponDescuento;
import com.ecomarket.cl.ecomarket.model.EmpleadoVentas;
import com.ecomarket.cl.ecomarket.service.EmpleadoVentasService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Tag(name = "EmpleadoVentas", description = "Operaciones relacionadas con los empleados de ventas")
@RestController
@RequestMapping("/api/empleado-ventas")
public class EmpleadoVentasController {

    @Autowired
    private EmpleadoVentasService empleadoVentasService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Listar todos los empleados de ventas", description = "Obtiene una lista de todos los empleados de ventas registrados.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Empleados listados correctamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public List<EmpleadoVentas> listar() {
        try {
            return empleadoVentasService.obtenerTodos();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al obtener empleados de ventas");
        }
    }

    @GetMapping("/{rut}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Obtener empleado de ventas por RUT", description = "Obtiene un empleado de ventas específico por su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Empleado encontrado correctamente"),
        @ApiResponse(responseCode = "404", description = "Empleado no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public EmpleadoVentas obtener(@PathVariable String rut) {
        try {
            return empleadoVentasService.obtenerPorRut(rut)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Empleado de ventas no encontrado con RUT: " + rut));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "RUT inválido: " + rut);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al obtener empleado de ventas");
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Crear un nuevo empleado de ventas", description = "Registra un nuevo empleado de ventas en el sistema.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Empleado creado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public EmpleadoVentas crear(@RequestBody EmpleadoVentas empleadoVentas) {
        try {
            return empleadoVentasService.guardar(empleadoVentas);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al crear empleado de ventas");
        }
    }

    @PutMapping("/{rut}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = "Actualizar empleado de ventas", description = "Actualiza los datos de un empleado de ventas existente.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Empleado actualizado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o RUT incorrecto"),
        @ApiResponse(responseCode = "404", description = "Empleado no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public EmpleadoVentas actualizar(@PathVariable String rut, @RequestBody EmpleadoVentas empleadoVentas) {
        empleadoVentas.setRut(rut);
        try {
            return empleadoVentasService.guardar(empleadoVentas);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al actualizar empleado de ventas");
        }
    }

    @DeleteMapping("/{rut}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Eliminar empleado de ventas", description = "Elimina un empleado de ventas del sistema por su RUT.")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Empleado eliminado correctamente"),
        @ApiResponse(responseCode = "404", description = "Empleado no encontrado"),
        @ApiResponse(responseCode = "400", description = "RUT inválido"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public void eliminar(@PathVariable String rut) {
        try {
            empleadoVentasService.eliminar(rut);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "RUT inválido: " + rut);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Empleado de ventas no encontrado con RUT: " + rut);
        }
    }

    @PostMapping("/{rut}/generar-cupon")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Generar cupón de descuento", description = "Genera un cupón de descuento para un empleado de ventas.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Cupón generado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "404", description = "Empleado no encontrado"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public CuponDescuento generarCupon(@PathVariable String rut, @RequestParam String codigo, @RequestParam double descuento) {
        try {
          
            return empleadoVentasService.generarCupon(codigo, descuento);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error al generar cupón");
        }
    }
}
